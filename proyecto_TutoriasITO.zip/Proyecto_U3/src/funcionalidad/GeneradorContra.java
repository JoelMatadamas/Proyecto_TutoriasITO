/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package funcionalidad;

import java.security.SecureRandom;

/**
 *
 * @author salin
 */
public class GeneradorContra {
    private static final String UPPER = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    private static final String LOWER = "abcdefghijklmnopqrstuvwxyz";
    private static final String DIGITS = "0123456789";
    private static final String SPECIAL = "!@#$%^&*()-_=+<>?";
    private static final String ALL = UPPER + LOWER + DIGITS + SPECIAL;
    
    private final int passwordLength; // Longitud de la contraseña

    // Constructor para establecer la longitud de la contraseña
    public GeneradorContra(int passwordLength) {
        this.passwordLength = passwordLength;
    }

    public String generarContraseña() {
        SecureRandom random = new SecureRandom();
        StringBuilder password = new StringBuilder(passwordLength);
        
        // Asegurarse de incluir al menos un carácter de cada tipo
        password.append(UPPER.charAt(random.nextInt(UPPER.length())));
        password.append(LOWER.charAt(random.nextInt(LOWER.length())));
        password.append(DIGITS.charAt(random.nextInt(DIGITS.length())));
        password.append(SPECIAL.charAt(random.nextInt(SPECIAL.length())));
        
        // Rellenar el resto de la contraseña
        for (int i = 4; i < passwordLength; i++) {
            password.append(ALL.charAt(random.nextInt(ALL.length())));
        }
        
        // Mezclar los caracteres
        return mezclar(password.toString());
    }

    private String mezclar(String password) {
        char[] caracteres = password.toCharArray();
        for (int i = 0; i < caracteres.length; i++) {
            int randomIndex = (int) (Math.random() * caracteres.length);
            char temp = caracteres[i];
            caracteres[i] = caracteres[randomIndex];
            caracteres[randomIndex] = temp;
        }
        return new String(caracteres);
    }
}
