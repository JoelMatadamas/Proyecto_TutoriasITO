/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package funcionalidad;

/**
 *
 * @author salin
 */
public class ValidacionNumero {
    public boolean validarLongitud(String numero) {
        return numero.length() == 10;
    }
    
    public boolean ValidanumC(String n){
        return n.length() == 8;
    }
}
