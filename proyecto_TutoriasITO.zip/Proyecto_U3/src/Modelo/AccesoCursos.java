/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import Controlador.Conexion;
import java.sql.*;
import java.util.*;
/**
 *
 * @author salin
 */
public class AccesoCursos {

    public List<Curso> getCursos() throws SQLException {
        List<Curso> listaCursos = new ArrayList<>();
        Connection con = Conexion.getConexion();
        
        if (con != null) {
            try (Statement stmt = con.createStatement();
                 ResultSet rs = stmt.executeQuery("SELECT * FROM curso")) {
                
                while (rs.next()) {
                    int idCurso = rs.getInt("idcurso");
                    int idMateria = rs.getInt("idMateria");
                    int idTutor = rs.getInt("idtutor");
                    Time horaInicio = rs.getTime("horaInicio");
                    Time horaFin = rs.getTime("horaFin");
                    String aula = rs.getString("aula");
                    
                    Curso curso = new Curso(idCurso, idTutor, idMateria, horaInicio, horaFin, aula);
                    listaCursos.add(curso);
                }
            } catch (SQLException e) {
                e.printStackTrace();
                throw new SQLException("Error al obtener cursos", e);
            }
        }
        
        return listaCursos;
    }
    
    public Curso obtenerCursoPorMateria(int idMateria) throws SQLException {
    Curso curso = null;
    Connection con = Conexion.getConexion();
    if (con != null) {
        try (PreparedStatement stmt = con.prepareStatement("SELECT * FROM curso WHERE idMateria = ?")) {
            stmt.setInt(1, idMateria); // Cambiamos el parámetro a idMateria
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    int idCurso = rs.getInt("idcurso");
                    int idMaterias = rs.getInt("idMateria");
                    int idTutor = rs.getInt("idtutor");
                    Time horaInicio = rs.getTime("hora_Inicio");
                    Time horaFin = rs.getTime("hora_fin");
                    String aula = rs.getString("aula");
                    
                     curso = new Curso(idCurso, idTutor, idMateria, horaInicio, horaFin, aula);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new SQLException("Error al obtener el curso", e);
        }
    }
    return curso;
}
    
    
    
    public Curso obtenerCursoPorTutor(int idTutor) throws SQLException {
    Curso curso = null;
    Connection con = Conexion.getConexion();
    if (con != null) {
        try (PreparedStatement stmt = con.prepareStatement("SELECT * FROM curso WHERE idTutor = ?")) {
            stmt.setInt(1, idTutor);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    int idCurso = rs.getInt("idcurso");
                    int idMaterias = rs.getInt("idMateria");
                    int idtut = rs.getInt("idtutor");
                    Time horaInicio = rs.getTime("hora_Inicio");
                    Time horaFin = rs.getTime("hora_fin");
                    String aula = rs.getString("aula");
                    
                     curso = new Curso(idCurso, idtut, idMaterias, horaInicio, horaFin, aula);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new SQLException("Error al obtener el curso", e);
        }
    }
    return curso;
}

    
    public boolean asignarCurso( int idTutor, int idMateria, Time horaInicio, Time horaFin, String aula) throws SQLException {
        Connection con = Conexion.getConexion();
        if (con != null) {
            String query = "INSERT INTO curso ( idtutor, idMateria, hora_inicio, hora_fin, aula) VALUES (?, ?, ?, ?, ?)";
            try (PreparedStatement stmt = con.prepareStatement(query)) {
                //stmt.setInt(1, idCurso);
                stmt.setInt(1, idTutor);
                stmt.setInt(2, idMateria);
                stmt.setTime(3, horaInicio);
                stmt.setTime(4, horaFin);
                stmt.setString(5, aula);
                int rowsInserted = stmt.executeUpdate();
                return rowsInserted > 0;
            } catch (SQLException e) {
                e.printStackTrace();
                throw new SQLException("Error al asignar el curso", e);
            }
        }
        return false;
    }
    
    public void insertarCurso(Curso curso) throws SQLException {
        Connection con = Conexion.getConexion();

        if (con != null) {
            String query = "INSERT INTO curso (idTutor, idMateria, hora_inicio, hora_fin, aula) VALUES (?, ?, ?, ?, ?)";
            try (PreparedStatement stmt = con.prepareStatement(query)) {
                stmt.setInt(1, curso.getIdMateria());
                stmt.setInt(2, curso.getIdTutor());
                stmt.setTime(3, curso.getHoraInicio());
                stmt.setTime(4, curso.getHoraFin());
                stmt.setString(5, curso.getAula());
                stmt.executeUpdate();
            }
        }
    }
    
    public List<Curso> getCursosPorTutor(int idTutor) throws SQLException {
    List<Curso> listaCursos = new ArrayList<>();
    Connection con = Conexion.getConexion();

    if (con != null) {
        String query = "SELECT * FROM curso WHERE idTutor = ?";
        try (PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setInt(1, idTutor);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    int idCurso = rs.getInt("idcurso");
                    int idMateria = rs.getInt("idMateria");
                    Time horaInicio = rs.getTime("hora_inicio");
                    Time horaFin = rs.getTime("hora_fin");
                    String aula = rs.getString("aula");

                    Curso curso = new Curso(idCurso, idTutor, idMateria, horaInicio, horaFin, aula);
                    listaCursos.add(curso);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new SQLException("Error al obtener los cursos por tutor", e);
        }
    }
    
    return listaCursos;
}

}