/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import Controlador.*;
import java.sql.*;
import java.util.*;
import javax.swing.*;
/**
 *
 * @author salin
 */
public class AccesoTutores {
    
    public List<Tutor> getTutores() throws SQLException {
        List<Tutor> listaTutores = new ArrayList<>();
        Connection con = Conexion.getConexion();
        
        if (con != null) {
            try (Statement stmt = con.createStatement();
                 ResultSet rs = stmt.executeQuery("SELECT * FROM tutores")) {
                
                while (rs.next()) {
                    int id = rs.getInt("idtutores");
                    int rfc = rs.getInt("rfc");
                    String nombre = rs.getString("nombres");
                    String Apaterno = rs.getString("ApPaterno");
                    String Amaterno = rs.getString("ApMaterno");
                    String numTel = rs.getString("numTelefonico");
                    String correo =rs.getString("correo");
                    
                    Tutor tutor = new Tutor(id, rfc, nombre, Apaterno, Amaterno, numTel, correo);
                    listaTutores.add(tutor);
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        
        return listaTutores;
    }
    
    
    public Tutor obtenerTutor(int id) throws SQLException {
        Tutor tutor = null;
        Connection con = Conexion.getConexion();
        if (con != null) {
            try (PreparedStatement stmt = con.prepareStatement("SELECT rfc, nombres, ApPaterno, ApMaterno, numTelefonico, correo FROM tutores WHERE `rfc` = ?")) {
                stmt.setInt(1, id);
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                    int rfc = rs.getInt("rfc");
                    String nombre = rs.getString("nombres");
                    String Apaterno = rs.getString("ApPaterno");
                    String Amaterno = rs.getString("ApMaterno");
                    String numTel = rs.getString("numTelefonico");
                    String Correo = rs.getString("correo");
                    
                     tutor = new Tutor(rfc, nombre, Apaterno, Amaterno, numTel);
                    }
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return tutor;
    }
    
    public Tutor obtenerTutorconID(int id) throws SQLException {
        Tutor tutor = null;
        Connection con = Conexion.getConexion();
        if (con != null) {
            try (PreparedStatement stmt = con.prepareStatement("SELECT * FROM tutores WHERE `idtutores` = ?")) {
                stmt.setInt(1, id);
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                    int idtut = rs.getInt("idtutores");
                    int rfc = rs.getInt("rfc");
                    String nombre = rs.getString("nombres");
                    String Apaterno = rs.getString("ApPaterno");
                    String Amaterno = rs.getString("ApMaterno");
                    String numTel = rs.getString("numTelefonico");
                    String correo =rs.getString("correo");
                    
                     tutor = new Tutor(idtut, rfc, nombre, Apaterno, Amaterno, numTel, correo);
                    }
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return tutor;
    }
    
    public Tutor getTutorconCorreo(String email) throws SQLException {
        Tutor tutor = null;
        Connection con = Conexion.getConexion();
        if (con != null) {
            try (PreparedStatement stmt = con.prepareStatement("SELECT * FROM tutores WHERE correo = ?")) {
                stmt.setString(1, email);
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                       
                        int idtut = rs.getInt("idtutores");
                    int rfc = rs.getInt("rfc");
                    String nombre = rs.getString("nombres");
                    String Apaterno = rs.getString("ApPaterno");
                    String Amaterno = rs.getString("ApMaterno");
                    String numTel = rs.getString("numTelefonico");
                    String correo =rs.getString("correo");
                    
                     tutor = new Tutor(idtut, rfc, nombre, Apaterno, Amaterno, numTel, correo);
                    }
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return tutor;
    }
    
     public boolean agregarTutor(String nombre, String Apaterno, String AMaterno, int rfc, String numC, String Correo) throws SQLException {
        Connection con = Conexion.getConexion();
        if(con != null){
        String sql = "INSERT INTO tutores ( rfc, nombres ,ApPaterno, ApMaterno,numTelefonico, correo) VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            //ps.setInt(1, idTutor);
            ps.setInt(1, rfc);
            ps.setString(2, nombre);
            ps.setString(3, Apaterno);
            ps.setString(4, AMaterno);
            ps.setString(5, numC);
            ps.setString(6, Correo);

            int rowsInserted = ps.executeUpdate();
            
            return rowsInserted > 0;
             
        } catch (SQLException ex) {
            throw new SQLException("Error al agregar el tutor: " + ex.getMessage(), ex);
        }}
        return false;
    }
    
    public boolean actualizarTutor(Tutor tutor) throws SQLException {
        Connection con = Conexion.getConexion();
        if (con != null) {
            String sql = "UPDATE tutores SET rfc = ?, nombres = ?, ApPaterno = ?, ApMaterno = ?, numTelefonico = ?, correo = ? WHERE idtutores = ?";
            try (PreparedStatement stmt = con.prepareStatement(sql)) {
                stmt.setInt(1, tutor.getRfc());
                stmt.setString(2, tutor.getNombre());
                stmt.setString(3, tutor.getAPaterno());
                stmt.setString(4, tutor.getAMaterno());
                stmt.setString(5, tutor.getNumTel());
                stmt.setString(6, tutor.getCorreo());
                stmt.setInt(7, tutor.getId());
                int rowsUpdated = stmt.executeUpdate();
                return rowsUpdated > 0;
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return false;
    }

    public boolean eliminarTutor(int id) throws SQLException {
        Connection con = Conexion.getConexion();
        if (con != null) {
            String sql = "DELETE FROM tutores WHERE idtutores = ?";
            try (PreparedStatement stmt = con.prepareStatement(sql)) {
                stmt.setInt(1, id);
                int rowsDeleted = stmt.executeUpdate();
                return rowsDeleted > 0;
            } catch (SQLException e) {
                e.printStackTrace();
                throw new SQLException("Error al eliminar el tutor"+id, e);
            }
        }
        return false;
    }
}
    

