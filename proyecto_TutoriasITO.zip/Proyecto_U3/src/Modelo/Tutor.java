/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author salin
 */
public class Tutor {
        private int id;
        private int rfc;
        private String nombre;
        private String APaterno;
        private String AMaterno;
        private String numTel;
        private String correo;
        
        public Tutor(){ }
        
        public Tutor(int id, int rfc, String nombre, String APaterno, String AMaterno, String numTel, String correo){
            this.id = id;
            this.rfc = rfc;
            this.nombre = nombre;
            this.APaterno = APaterno;
            this.AMaterno = AMaterno;
            this.numTel = numTel;
            this.correo = correo;
        }
        
        public Tutor( int rfc, String nombre, String APaterno, String AMaterno, String numTel){
            this.rfc = rfc;
            this.nombre = nombre;
            this.APaterno = APaterno;
            this.AMaterno = AMaterno;
            this.numTel = numTel;
        }
        

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getAPaterno() {
        return APaterno;
    }

    public void setAPaterno(String APaterno) {
        this.APaterno = APaterno;
    }

    public String getAMaterno() {
        return AMaterno;
    }

    public void setAMaterno(String AMaterno) {
        this.AMaterno = AMaterno;
    }

    public int getRfc() {
        return rfc;
    }

    public void setRfc(int rfc) {
        this.rfc = rfc;
    }

    public String getNumTel() {
        return numTel;
    }

    public void setNumTel(String numTel) {
        this.numTel = numTel;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

        
        
}
