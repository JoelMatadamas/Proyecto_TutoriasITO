/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import Controlador.*;

/**
 *
 * @author salin
 */
public class Usuario {
    private String correo;
    private String contra;
    private int nivel;
    private String usuario;

    public Usuario(){
        
    }
    public Usuario(String correo, String contra, int nivel, String usuario) {
        this.correo = correo;
        this.contra = contra;
        this.nivel = nivel;
        this.usuario = usuario;
    }

    public String getCorreo() {
        return correo;
    }

    public String getContraseña() {
        return contra;
    }

    public int getNivel() {
        return nivel;
    }

    public String getUsuario(){
        return usuario;
    }
}
