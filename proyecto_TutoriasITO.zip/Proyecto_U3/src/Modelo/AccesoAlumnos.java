/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import Controlador.*;
import java.sql.*;
import java.util.*;
import javax.swing.*;
/**
 *
 * @author salin
 */
public class AccesoAlumnos {
    
    public List<Alumno> getAlumnos() throws SQLException {
        List<Alumno> listaAlumnos = new ArrayList<>();
        Connection con = Conexion.getConexion();
        
        if (con != null) {
            try (Statement stmt = con.createStatement();
                 ResultSet rs = stmt.executeQuery("SELECT * FROM alumnos")) {
                
                while (rs.next()) {
                    int numControl = rs.getInt("NumControl");
                    String nombre = rs.getString("Nombres");
                    String Apaterno = rs.getString("ApPaterno");
                    String Amaterno = rs.getString("ApMaterno");
                    int semestre = rs.getInt("Semestre");
                    String carrera = rs.getString("Carrera");
                    String correo = rs.getNString("Correo");
                    int materia = rs.getInt("idmaterias");
                    
                    
                    Alumno alumno = new Alumno(numControl, nombre, Apaterno, Amaterno, semestre, carrera, materia, correo);
                    listaAlumnos.add(alumno);
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        
        return listaAlumnos;
    }
    
    
    public Alumno obtenerAlumno(int id) throws SQLException {
        Alumno alumno = null;
        Connection con = Conexion.getConexion();
        if (con != null) {
            try (PreparedStatement stmt = con.prepareStatement("SELECT * FROM alumnos WHERE `NumControl` = ?")) {
                stmt.setInt(1, id);
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                    int numControl = rs.getInt("NumControl");
                    String nombre = rs.getString("Nombres");
                    String Apaterno = rs.getString("ApPaterno");
                    String Amaterno = rs.getString("ApMaterno");
                    int semestre = rs.getInt("Semestre");
                    String carrera = rs.getString("Carrera");
                    String correo = rs.getNString("Correo");
                   int materia = rs.getInt("idmaterias");
                    
                    
                     alumno = new Alumno(numControl, nombre, Apaterno, Amaterno, semestre, carrera, materia, correo);
                    }
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return alumno;
    }
    
    public boolean asignarMateria(int numControl, int idMateria) throws SQLException {
        Connection con = Conexion.getConexion();
        if (con != null) {
            String query = "UPDATE alumnos SET idmaterias = ? WHERE NumControl = ?";
            try (PreparedStatement stmt = con.prepareStatement(query)) {
                stmt.setInt(1, idMateria);
                stmt.setInt(2, numControl);
                int rowsUpdated = stmt.executeUpdate();
                return rowsUpdated > 0;
            } catch (SQLException e) {
                e.printStackTrace();
                throw new SQLException("Error al asignar materia al alumno", e);
            }
        }
        return false;
    }
    
    
    public Alumno obtenerAlumnoPorIdMateria(int idMateria) throws SQLException {
    Alumno alumno = null;
    Connection con = Conexion.getConexion();
    if (con != null) {
        try (PreparedStatement stmt = con.prepareStatement("SELECT * FROM alumnos WHERE `idmaterias` = ?")) {
            stmt.setInt(1, idMateria);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    int numControl = rs.getInt("NumControl");
                    String nombre = rs.getString("Nombres");
                    String Apaterno = rs.getString("ApPaterno");
                    String Amaterno = rs.getString("ApMaterno");
                    int semestre = rs.getInt("Semestre");
                    String carrera = rs.getString("Carrera");
                    String correo = rs.getNString("Correo");
                     int materia = rs.getInt("idmaterias");
                    
                    
                     alumno = new Alumno(numControl, nombre, Apaterno, Amaterno, semestre, carrera, materia, correo);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    return alumno;
}

    
    public List<Alumno> getAlumnosPorIdMateria(int idMateria) throws SQLException {
        List<Alumno> listaAlumnos = new ArrayList<>();
        Connection con = Conexion.getConexion();
        
        if (con != null) {
            try (PreparedStatement stmt = con.prepareStatement("SELECT * FROM alumnos WHERE `idmaterias` = ?")) {
                stmt.setInt(1, idMateria);
                try (ResultSet rs = stmt.executeQuery()) {
                    while (rs.next()) {
                        int numControl = rs.getInt("NumControl");
                        String nombre = rs.getString("Nombres");
                        String Apaterno = rs.getString("ApPaterno");
                        String Amaterno = rs.getString("ApMaterno");
                        int semestre = rs.getInt("Semestre");
                        String carrera = rs.getString("Carrera");
                        String correo = rs.getNString("Correo");
                         int materia = rs.getInt("idmaterias");
                    
                    
                    Alumno alumno = new Alumno(numControl, nombre, Apaterno, Amaterno, semestre, carrera, materia, correo);
                        listaAlumnos.add(alumno);
                    }
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        
        return listaAlumnos;
    }
    
    
    public Alumno obtenerAlumnoPorNombre(String nombre) throws SQLException {
    Alumno alumno = null;
    Connection con = Conexion.getConexion();
    
    if (con != null) {
        try (PreparedStatement stmt = con.prepareStatement("SELECT * FROM alumnos WHERE Nombres = ?")) {
            stmt.setString(1, nombre); // Ajusta aquí para buscar por el nombre
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    int numControl = rs.getInt("NumControl");
                    String Apaterno = rs.getString("ApPaterno");
                    String Amaterno = rs.getString("ApMaterno");
                    int semestre = rs.getInt("Semestre");
                    String carrera = rs.getString("Carrera");
                    String correo = rs.getNString("Correo");
                    int materia = rs.getInt("idmaterias");
                    
                    
                     alumno = new Alumno(numControl, nombre, Apaterno, Amaterno, semestre, carrera, materia, correo);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    return alumno; // Puede ser null si no se encuentra el alumno
}

    
     public void agregarAlumno(Alumno alumno) throws SQLException {
        Connection con = Conexion.getConexion();
        String sql = "INSERT INTO alumnos (NumControl, Nombres, ApPaterno, ApMaterno, semestre, carrera, Correo) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, alumno.getNumControl());
            ps.setString(2, alumno.getNombre());
            ps.setString(3, alumno.getAPaterno());
            ps.setString(4, alumno.getAMaterno());
            ps.setInt(5, alumno.getSemestre());
            ps.setString(6, alumno.getCarrera());
            ps.setString(7, alumno.getCorreo());

            ps.executeUpdate();
        } catch (SQLException ex) {
            throw new SQLException("Error al agregar el alumno: " + ex.getMessage(), ex);
        }
    }
    
    
    public boolean actualizarAlumno(Alumno alumno) throws SQLException {
        Connection con = Conexion.getConexion();
        if (con != null) {
            String query = "UPDATE alumnos SET Nombres = ?, ApPaterno = ?, ApMaterno = ?, Semestre = ?, Carrera = ?, Correo = ? WHERE NumControl = ?";
            try (PreparedStatement stmt = con.prepareStatement(query)) {
                stmt.setString(1, alumno.getNombre());
                stmt.setString(2, alumno.getAPaterno());
                stmt.setString(3, alumno.getAMaterno());
                stmt.setInt(4, alumno.getSemestre());
                stmt.setString(5, alumno.getCarrera());
                stmt.setString(6, alumno.getCorreo());
                stmt.setInt(7, alumno.getNumControl());
                
                int rowsUpdated = stmt.executeUpdate();
                return rowsUpdated > 0;
            } catch (SQLException e) {
                e.printStackTrace();
                throw new SQLException("Error al actualizar el alumno", e);
            }
        }
        return false;
    }

    public boolean eliminarAlumno(int numControl) throws SQLException {
        Connection con = Conexion.getConexion();
        if (con != null) {
            String query = "DELETE FROM alumnos WHERE NumControl = ?";
            try (PreparedStatement stmt = con.prepareStatement(query)) {
                stmt.setInt(1, numControl);
                int rowsDeleted = stmt.executeUpdate();
                return rowsDeleted > 0;
            } catch (SQLException e) {
                e.printStackTrace();
                throw new SQLException("Error al eliminar el alumno", e);
            }
        }
        return false;
    }
    
    
}
    

