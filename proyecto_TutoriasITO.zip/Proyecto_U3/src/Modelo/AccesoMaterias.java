/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import Controlador.*;
import java.sql.*;
import java.util.*;
import javax.swing.*;
/**
 *
 * @author salin
 */
public class AccesoMaterias {
    
    public List<Materia> getMaterias() throws SQLException {
        List<Materia> listaMaterias = new ArrayList<>();
        Connection con = Conexion.getConexion();
        
        if (con != null) {
            try (Statement stmt = con.createStatement();
                 ResultSet rs = stmt.executeQuery("SELECT * FROM materias")) {
                
                while (rs.next()) {
                    int id = rs.getInt("idmaterias");
                    String nombre = rs.getString("nombre");
                    int capacidad = rs.getInt("capacidad");
                    String carrera = rs.getString("carrera");
                    int semestre = rs.getInt("semestre");
                    
                    Materia materia = new Materia(id, nombre, capacidad, carrera, semestre);
                    listaMaterias.add(materia);
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        
        return listaMaterias;
    }
    
    public List<Materia> getMateriasFiltro(String carrera, int semestre) throws SQLException {
    List<Materia> listaMaterias = new ArrayList<>();
    Connection con = Conexion.getConexion();
    
    if (con != null) {
        String query = "SELECT * FROM materias WHERE carrera = ? AND semestre = ?";
        try (PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setString(1, carrera);
            stmt.setInt(2, semestre);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    int id = rs.getInt("idmaterias");
                    String nombre = rs.getString("nombre");
                    int capacidad = rs.getInt("capacidad");
                    String carreraMateria = rs.getString("carrera");
                    int semestreMateria = rs.getInt("semestre");

                    Materia materia = new Materia(id, nombre, capacidad, carreraMateria, semestreMateria);
                    listaMaterias.add(materia);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new SQLException("Error al obtener materias", e);
        }
    }
    return listaMaterias;
}

    public Materia obtenerMateria(int id) throws SQLException {
        Materia materia = null;
        Connection con = Conexion.getConexion();
        if (con != null) {
            try (PreparedStatement stmt = con.prepareStatement("SELECT * FROM  materias WHERE `idmaterias` = ?")) {
                stmt.setInt(1, id);
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                    int idmat = rs.getInt("idmaterias");
                    String nombre = rs.getString("nombre");
                    int capacidad = rs.getInt("capacidad");
                    String carrera = rs.getString("carrera");
                    int semestre = rs.getInt("Semestre");
                    
                     materia = new Materia(idmat, nombre, capacidad, carrera, semestre);
                    }
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return materia;
    }
    
    public List<Materia> obtenerMateriasPorId(int id) throws SQLException {
    List<Materia> listaMaterias = new ArrayList<>();
    Connection con = Conexion.getConexion();
    
    if (con != null) {
        try (PreparedStatement stmt = con.prepareStatement("SELECT * FROM materias WHERE `idmaterias` = ?")) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    int idmat = rs.getInt("idmaterias");
                    String nombre = rs.getString("nombre");
                    int capacidad = rs.getInt("capacidad");
                    String carrera = rs.getString("carrera");
                    int semestre = rs.getInt("Semestre");
                    
                    Materia materia = new Materia(idmat, nombre, capacidad, carrera, semestre);
                    listaMaterias.add(materia);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    return listaMaterias;
}

public List<Materia> obtenerMateriasPorNombre(String nombre) throws SQLException {
    List<Materia> listaMaterias = new ArrayList<>();
    Connection con = Conexion.getConexion();
    
    if (con != null) {
        try (PreparedStatement stmt = con.prepareStatement("SELECT * FROM materias WHERE `nombre` = ?")) {
            stmt.setString(1, nombre);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    int idmat = rs.getInt("idmaterias");
                    String nombreMateria = rs.getString("nombre");
                    int capacidad = rs.getInt("capacidad");
                    String carrera = rs.getString("carrera");
                    int semestre = rs.getInt("Semestre");
                    
                    Materia materia = new Materia(idmat, nombreMateria, capacidad, carrera, semestre);
                    listaMaterias.add(materia);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    return listaMaterias;
}


public Materia obtenerMateriaPorNombre(String nombre) throws SQLException {
    Materia materia = null;
    Connection con = Conexion.getConexion();
    
    if (con != null) {
        try (PreparedStatement stmt = con.prepareStatement("SELECT * FROM materias WHERE `nombre` = ?")) {
            stmt.setString(1, nombre);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    int idmat = rs.getInt("idmaterias");
                    String nombreMateria = rs.getString("nombre");
                    int capacidad = rs.getInt("capacidad");
                    String carrera = rs.getString("carrera");
                    int semestre = rs.getInt("Semestre");
                    
                    materia = new Materia(idmat, nombreMateria, capacidad, carrera, semestre);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    return materia; // Puede ser null si no se encuentra ninguna materia
}

  
}
    

