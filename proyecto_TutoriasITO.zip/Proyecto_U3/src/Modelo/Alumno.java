/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author salin
 */
public class Alumno {
        private int numControl;
        private String nombre;
        private String APaterno;
        private String AMaterno;
        private int semestre;
        private String carrera;
        private int materia;
        private String correo;
        
        public Alumno(){ }
        
        public Alumno(int numControl, String nombre, String APaterno, String AMaterno, int semestre, String carrera, int materia, String correo){
            this.numControl = numControl;
            this.nombre = nombre;
            this.APaterno = APaterno;
            this.AMaterno = AMaterno;
            this.semestre = semestre;
            this.carrera = carrera;
            this.materia = materia;
            this.correo = correo;
        }
        public Alumno(int numControl, String nombre, String APaterno, String AMaterno, int semestre, String carrera, String correo){
            this.numControl = numControl;
            this.nombre = nombre;
            this.APaterno = APaterno;
            this.AMaterno = AMaterno;
            this.semestre = semestre;
            this.carrera = carrera;
            this.correo = correo;
        }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getAPaterno() {
        return APaterno;
    }

    public void setAPaterno(String APaterno) {
        this.APaterno = APaterno;
    }

    public String getAMaterno() {
        return AMaterno;
    }

    public void setAMaterno(String AMaterno) {
        this.AMaterno = AMaterno;
    }

    public int getSemestre() {
        return semestre;
    }

    public void setSemestre(int semestre) {
        this.semestre = semestre;
    }

    public String getCarrera() {
        return carrera;
    }

    public void setCarrera(String carrera) {
        this.carrera = carrera;
    }

    public int getMateria() {
        return materia;
    }

    public void setMateria(int materia) {
        this.materia = materia;
    }

    public int getNumControl() {
        return numControl;
    }

    public void setNumControl(int numControl) {
        this.numControl = numControl;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }
        
        
        
        
}
