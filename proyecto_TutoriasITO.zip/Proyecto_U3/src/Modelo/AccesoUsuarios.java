/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import Controlador.*;
import java.sql.*;

public class AccesoUsuarios {
    
   public Usuario getUsuarios(String email) throws SQLException {
        Usuario usuario = null;
        Connection con = Conexion.getConexion();
        if (con != null) {
            try (PreparedStatement stmt = con.prepareStatement("SELECT correo, contraseña, nivel, usuario FROM usuarios WHERE correo = ?")) {
                stmt.setString(1, email);
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        String correo = rs.getString("correo");
                        String contraseña = rs.getString("contraseña");
                        int nivel = rs.getInt("nivel");
                        String user = rs.getString("usuario");
                        usuario = new Usuario(correo, contraseña, nivel, user);
                    }
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return usuario;
    }
   
    public boolean agregarUsuario(String correo, String contraseña, int nivel, String user) throws SQLException {
        boolean agregado = false;
        Connection con = Conexion.getConexion();
        if (con != null) {
            String sql = "INSERT INTO usuarios (correo, contraseña, nivel, usuario) VALUES (?, ?, ?, ?)";
            try (PreparedStatement stmt = con.prepareStatement(sql)) {
                stmt.setString(1, correo);
                stmt.setString(2, contraseña);
                stmt.setInt(3, nivel);
                stmt.setString(4, user);
                
                int filasInsertadas = stmt.executeUpdate();
                if (filasInsertadas > 0) {
                    agregado = true;
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return agregado;
    }
}
