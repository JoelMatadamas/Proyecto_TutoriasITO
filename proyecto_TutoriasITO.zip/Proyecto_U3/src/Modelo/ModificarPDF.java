/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDType1Font;

import java.io.File;
import java.io.IOException;
import org.apache.pdfbox.Loader;
import org.apache.pdfbox.pdfwriter.compress.CompressParameters;
import org.apache.pdfbox.pdmodel.font.Standard14Fonts;

public class ModificarPDF {
    public static void main(String[] args) {
        String pdfPath = "C:\\Users\\salin\\OneDrive\\Documentos\\Tec\\PdfProyecto\\Informacion.pdf"; // Ruta al PDF que deseas modificar
        String outputPath = "C:\\Users\\salin\\OneDrive\\Documentos\\Tec\\RecibirPDF\\Asignacion1.pdf"; // Ruta donde se guardará el PDF modificado

        try (PDDocument document = Loader.loadPDF(new File(pdfPath))) {
            // Suponemos que deseas modificar la primera página
            PDPage page = document.getPage(0);

            // Crear un flujo de contenido para la página
            try (PDPageContentStream contentStream = new PDPageContentStream(document, page, PDPageContentStream.AppendMode.APPEND, true, true)) {
                // Configura la fuente y el tamaño
                contentStream.setFont(new PDType1Font(Standard14Fonts.FontName.HELVETICA), 11);
                
                contentStream.beginText();
                contentStream.newLineAtOffset(340, 288); // Ajusta la posición del texto
                contentStream.showText("Texto agregado al PDF.");
                contentStream.endText();
                
                contentStream.beginText();
                contentStream.newLineAtOffset(340, 253); // Ajusta la posición del texto
                contentStream.showText("Texto agregado al PDF.");
                contentStream.endText();
                
               contentStream.beginText();
                contentStream.newLineAtOffset(340, 218); // Ajusta la posición del texto
                contentStream.showText("Texto agregado al PDF.");
                contentStream.endText();
                
                contentStream.beginText();
                contentStream.newLineAtOffset(340, 183); // Ajusta la posición del texto
                contentStream.showText("Texto agregado al PDF.");
                contentStream.endText();
                
                contentStream.beginText();
                contentStream.newLineAtOffset(340, 148); // Ajusta la posición del texto
                contentStream.showText("Texto agregado al PDF.");
                contentStream.endText();
            }

            // Guardar el documento modificado
            document.save(outputPath, CompressParameters.NO_COMPRESSION);
            System.out.println("PDF modificado y guardado en: " + outputPath);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
