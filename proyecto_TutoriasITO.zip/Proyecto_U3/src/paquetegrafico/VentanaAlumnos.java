/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package paquetegrafico;

import Modelo.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.*;
import javax.swing.table.DefaultTableModel;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author salin
 */
public class VentanaAlumnos extends javax.swing.JFrame {
         private JLabel lblmenuBarras;
         private ImageIcon menuba;
         private boolean configclick;
         private AsignarMaterias materias;
         private AgregarAlumno agregar;
         private Usuario usuario;
         private Alumno alumno;
         private Alumno alumnoSeleccionado;
         private Alumno eleccioAlumno;
         private AccesoAlumnos alumnos;
         private DefaultTableModel modelon;
    /**
     * Creates new form MenuPrincipal
     */
    public VentanaAlumnos() {
        initComponents();
        alumno = new Alumno();
        alumnos = new AccesoAlumnos();
        materias = new AsignarMaterias(null,true);
        agregar = new AgregarAlumno(null,true);
        lblmenuBarras = new JLabel();
        menuba = new ImageIcon(getClass().getResource("menuBarrasfn.png"));
        lblmenuBarras.setIcon(menuba);
        lblmenuBarras.setBounds(5, 5, 25, 25);
        lblmenuBarras.setVisible(false);
        lblmenuBarras.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        panelMenu.setVisible(true);
        panelFondo.add(lblmenuBarras);
        configclick = true;
        btnAsignar.setEnabled(false);
        btnDeseleccionar.setEnabled(false);
        btnActualizar.setEnabled(false);
        btnEliminar.setEnabled(false);
         modelon = (DefaultTableModel) tablaDatos.getModel();

         lblmenuBarras.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                menuBarrasMouseClicked(e);
            }
        });
         
         // Paaar qu la tabla sea editable
        DefaultTableModel modelo = (DefaultTableModel) tablaDatos.getModel();
        modelo.setColumnIdentifiers(new String[]{"NumControl", "Nombre", "APaterno", "AMaterno", "Semestre", "Carrera","Correo"});
        tablaDatos.setModel(modelo);
        tablaDatos.setDefaultEditor(Object.class, new DefaultCellEditor(new JTextField()));   

        // Asignar editores personalizados
        tablaDatos.getColumnModel().getColumn(0).setCellEditor(new NumericCellEditor()); // NumControl
        tablaDatos.getColumnModel().getColumn(4).setCellEditor(new NumericCellEditor()); // Semestre
        tablaDatos.getColumnModel().getColumn(1).setCellEditor(new LetterCellEditor()); // Nombre
        tablaDatos.getColumnModel().getColumn(2).setCellEditor(new LetterCellEditor()); // ApPaterno
        tablaDatos.getColumnModel().getColumn(3).setCellEditor(new LetterCellEditor()); // ApMaterno
        tablaDatos.getColumnModel().getColumn(5).setCellEditor(new LetterCellEditor()); // Carrera
        tablaDatos.getColumnModel().getColumn(6).setCellEditor(new LetterCellEditor());// Correo
    }
        public class NumericCellEditor extends DefaultCellEditor {

        public NumericCellEditor() {
            super(new JTextField());
            ((JTextField) getComponent()).addKeyListener(new KeyAdapter() {
                public void keyTyped(KeyEvent e) {
                    char c = e.getKeyChar();
                    if (!Character.isDigit(c)) {
                        e.consume(); // Ignorar el evento si no es un dígito
                    }
                }
            });
        }
    }

    public class LetterCellEditor extends DefaultCellEditor {

        public LetterCellEditor() {
            super(new JTextField());
            ((JTextField) getComponent()).addKeyListener(new KeyAdapter() {
                public void keyTyped(KeyEvent e) {
                    char c = e.getKeyChar();
                    if (!Character.isLetter(c) && c != KeyEvent.VK_SPACE) {
                        e.consume(); // Ignorar el evento si no es una letra o espacio
                    }
                }
            });
        }
         
         
    }

    public void asignarUsuario(Usuario usuario){
        this.usuario = usuario;
        lblUsuario.setText(usuario.getUsuario());
    }
    
    private void cargarDatos() {
         List<Alumno> listaAlumnos;
    try {
        listaAlumnos = alumnos.getAlumnos();
        DefaultTableModel modelo = (DefaultTableModel) tablaDatos.getModel();
        modelo.setRowCount(0);
        
        for (Alumno alum : listaAlumnos) {
            Object[] fila = {
                alum.getNumControl(), 
                alum.getNombre(), 
                alum.getAPaterno(), 
                alum.getAMaterno(), 
                alum.getSemestre(), 
                alum.getCarrera(),
                alum.getCorreo()
            };
            modelo.addRow(fila);
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    }
    
    private void buscarAlumno(){
        
        if(txtnumControl.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "Ingresa un numero de control");
        }
        else{
            int numControl = Integer.parseInt(txtnumControl.getText());
            try {
            alumno = alumnos.obtenerAlumno(numControl);
                } catch (SQLException ex) {
            Logger.getLogger(Loggin.class.getName()).log(Level.SEVERE, null, ex);
        }
            
        if(alumno != null){
            DefaultTableModel modelo = (DefaultTableModel) tablaDatos.getModel();
        modelo.setRowCount(0); 
        
        Object[] fila = {
            alumno.getNumControl(), 
            alumno.getNombre(), 
            alumno.getAPaterno(), 
            alumno.getAMaterno(), 
            alumno.getSemestre(), 
            alumno.getCarrera(),
            alumno.getCorreo()
        };
        modelo.addRow(fila);
    } else {
        JOptionPane.showMessageDialog(this, "Número de control no encontrado");
        }
        }
    }
    
    private void obtenerAlumnoSeleccionado() {
        int seleccion = tablaDatos.getSelectedRow();
        if (seleccion != -1) {
            int numControl = (int) tablaDatos.getValueAt(seleccion, 0);
            try {
                alumnoSeleccionado = alumnos.obtenerAlumno(numControl);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        menuOpciones = new javax.swing.JPopupMenu();
        menuCrearAdmin = new javax.swing.JMenuItem();
        separador1 = new javax.swing.JPopupMenu.Separator();
        menuoptCerrar = new javax.swing.JMenuItem();
        panelFondo = new javax.swing.JPanel();
        panelMenu = new javax.swing.JPanel();
        lblHogar = new javax.swing.JLabel();
        lblTutores = new javax.swing.JLabel();
        lblMaterias = new javax.swing.JLabel();
        lblRetroceder = new javax.swing.JLabel();
        lblConfig = new javax.swing.JLabel();
        paneltitulo = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        lblImagenAdorno = new javax.swing.JLabel();
        lblUsuario = new javax.swing.JLabel();
        panelAlumnos = new javax.swing.JPanel();
        filler1 = new javax.swing.Box.Filler(new java.awt.Dimension(0, 0), new java.awt.Dimension(0, 0), new java.awt.Dimension(0, 0));
        panelBusqueda = new javax.swing.JPanel();
        lblnumControl = new javax.swing.JLabel();
        txtnumControl = new javax.swing.JTextField();
        btnBuscar = new javax.swing.JButton();
        btnAlumnos = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JSeparator();
        panelTabla = new javax.swing.JScrollPane();
        tablaDatos = new javax.swing.JTable();
        panelBotones = new javax.swing.JPanel();
        btnAsignar = new javax.swing.JButton();
        btnDeseleccionar = new javax.swing.JButton();
        btnRegistro = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        btnActualizar = new javax.swing.JButton();

        menuCrearAdmin.setText("Crear nuevo administrador");
        menuCrearAdmin.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                menuCrearAdminMouseClicked(evt);
            }
        });
        menuCrearAdmin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuCrearAdminActionPerformed(evt);
            }
        });
        menuOpciones.add(menuCrearAdmin);
        menuOpciones.add(separador1);

        menuoptCerrar.setText("Cerrar Sesión");
        menuoptCerrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuoptCerrarActionPerformed(evt);
            }
        });
        menuOpciones.add(menuoptCerrar);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Menu Principal");
        setResizable(false);

        panelFondo.setBackground(new java.awt.Color(255, 255, 255));

        panelMenu.setBackground(new java.awt.Color(0, 0, 204));

        lblHogar.setForeground(new java.awt.Color(255, 255, 255));
        lblHogar.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblHogar.setText("Hogar");
        lblHogar.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        lblHogar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblHogarMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblHogarMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblHogarMouseExited(evt);
            }
        });

        lblTutores.setForeground(new java.awt.Color(255, 255, 255));
        lblTutores.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTutores.setText("Tutores");
        lblTutores.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        lblTutores.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblTutoresMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblTutoresMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblTutoresMouseExited(evt);
            }
        });

        lblMaterias.setForeground(new java.awt.Color(255, 255, 255));
        lblMaterias.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblMaterias.setText("Materias");
        lblMaterias.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        lblMaterias.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblMateriasMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblMateriasMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblMateriasMouseExited(evt);
            }
        });

        lblRetroceder.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/flecha.png"))); // NOI18N
        lblRetroceder.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblRetroceder.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblRetrocederMouseClicked(evt);
            }
        });

        lblConfig.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/configuracionb.png"))); // NOI18N
        lblConfig.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblConfig.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblConfigMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout panelMenuLayout = new javax.swing.GroupLayout(panelMenu);
        panelMenu.setLayout(panelMenuLayout);
        panelMenuLayout.setHorizontalGroup(
            panelMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelMenuLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblHogar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 88, Short.MAX_VALUE)
                    .addComponent(lblTutores, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblMaterias, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelMenuLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(lblRetroceder, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelMenuLayout.createSequentialGroup()
                        .addComponent(lblConfig, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        panelMenuLayout.setVerticalGroup(
            panelMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelMenuLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblRetroceder, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(39, 39, 39)
                .addComponent(lblHogar, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblTutores, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblMaterias, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblConfig, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        paneltitulo.setBackground(new java.awt.Color(204, 204, 204));

        jLabel1.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 24)); // NOI18N
        jLabel1.setText("Alumnos");
        paneltitulo.add(jLabel1);

        lblImagenAdorno.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/userfn.png"))); // NOI18N

        lblUsuario.setFont(new java.awt.Font("Segoe UI Semibold", 1, 12)); // NOI18N
        lblUsuario.setText("Usuario");

        panelAlumnos.setBackground(new java.awt.Color(255, 255, 255));

        panelBusqueda.setBackground(new java.awt.Color(255, 255, 255));

        lblnumControl.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblnumControl.setText("Numero de Control:");

        txtnumControl.setBorder(null);
        txtnumControl.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtnumControlKeyTyped(evt);
            }
        });

        btnBuscar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnBuscar.setText("Buscar");
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });

        btnAlumnos.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnAlumnos.setText("Todos los alumnos");
        btnAlumnos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAlumnosActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelBusquedaLayout = new javax.swing.GroupLayout(panelBusqueda);
        panelBusqueda.setLayout(panelBusquedaLayout);
        panelBusquedaLayout.setHorizontalGroup(
            panelBusquedaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelBusquedaLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblnumControl)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelBusquedaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jSeparator1)
                    .addComponent(txtnumControl, javax.swing.GroupLayout.DEFAULT_SIZE, 165, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnBuscar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnAlumnos)
                .addGap(29, 29, 29))
        );
        panelBusquedaLayout.setVerticalGroup(
            panelBusquedaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelBusquedaLayout.createSequentialGroup()
                .addGap(11, 11, 11)
                .addGroup(panelBusquedaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblnumControl)
                    .addComponent(txtnumControl, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnBuscar)
                    .addComponent(btnAlumnos))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24))
        );

        panelTabla.setBackground(new java.awt.Color(255, 255, 255));
        panelTabla.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panelTablaMouseClicked(evt);
            }
        });

        tablaDatos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Num. Control", "Nombres", "Ap. Paterno", "Ap. Materno", "Semestre", "Carrera", "Correo"
            }
        ));
        tablaDatos.setRowHeight(30);
        tablaDatos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaDatosMouseClicked(evt);
            }
        });
        panelTabla.setViewportView(tablaDatos);

        panelBotones.setBackground(new java.awt.Color(255, 255, 255));

        btnAsignar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnAsignar.setText("Asignar Materia");
        btnAsignar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAsignarActionPerformed(evt);
            }
        });

        btnDeseleccionar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnDeseleccionar.setText("Deseleccionar");
        btnDeseleccionar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeseleccionarActionPerformed(evt);
            }
        });

        btnRegistro.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnRegistro.setText("Agregar nuevo Alumno");
        btnRegistro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegistroActionPerformed(evt);
            }
        });

        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        btnActualizar.setText("Actualizar");
        btnActualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActualizarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelBotonesLayout = new javax.swing.GroupLayout(panelBotones);
        panelBotones.setLayout(panelBotonesLayout);
        panelBotonesLayout.setHorizontalGroup(
            panelBotonesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelBotonesLayout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(btnAsignar)
                .addGap(18, 18, 18)
                .addComponent(btnDeseleccionar)
                .addGap(18, 18, 18)
                .addComponent(btnRegistro)
                .addGap(18, 18, 18)
                .addComponent(btnEliminar)
                .addGap(18, 18, 18)
                .addComponent(btnActualizar)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        panelBotonesLayout.setVerticalGroup(
            panelBotonesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelBotonesLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelBotonesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAsignar)
                    .addComponent(btnDeseleccionar)
                    .addComponent(btnRegistro)
                    .addComponent(btnEliminar)
                    .addComponent(btnActualizar))
                .addContainerGap(20, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout panelAlumnosLayout = new javax.swing.GroupLayout(panelAlumnos);
        panelAlumnos.setLayout(panelAlumnosLayout);
        panelAlumnosLayout.setHorizontalGroup(
            panelAlumnosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelAlumnosLayout.createSequentialGroup()
                .addGroup(panelAlumnosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(panelBotones, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(panelTabla, javax.swing.GroupLayout.DEFAULT_SIZE, 781, Short.MAX_VALUE)
                    .addComponent(panelBusqueda, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(filler1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        panelAlumnosLayout.setVerticalGroup(
            panelAlumnosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelAlumnosLayout.createSequentialGroup()
                .addComponent(panelBusqueda, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(panelAlumnosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelAlumnosLayout.createSequentialGroup()
                        .addGap(89, 89, 89)
                        .addComponent(filler1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelAlumnosLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(panelTabla, javax.swing.GroupLayout.PREFERRED_SIZE, 385, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(panelBotones, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(17, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout panelFondoLayout = new javax.swing.GroupLayout(panelFondo);
        panelFondo.setLayout(panelFondoLayout);
        panelFondoLayout.setHorizontalGroup(
            panelFondoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelFondoLayout.createSequentialGroup()
                .addComponent(panelMenu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(panelFondoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(paneltitulo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelFondoLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 703, Short.MAX_VALUE)
                        .addComponent(lblImagenAdorno, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblUsuario)
                        .addGap(25, 25, 25))
                    .addGroup(panelFondoLayout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(panelAlumnos, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        panelFondoLayout.setVerticalGroup(
            panelFondoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelMenu, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(panelFondoLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelFondoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblImagenAdorno, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblUsuario, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(paneltitulo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(panelAlumnos, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelFondo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelFondo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void lblRetrocederMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblRetrocederMouseClicked
        panelMenu.setVisible(false);
        lblmenuBarras.setVisible(true);
    }//GEN-LAST:event_lblRetrocederMouseClicked

    private void lblConfigMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblConfigMouseClicked
        if(configclick == true){
        menuOpciones.show(this, lblConfig.getX(), lblConfig.getY()-25);
        configclick=false;
        }else if(configclick == false){
            menuOpciones.setVisible(false);
            configclick = true;
        }
    }//GEN-LAST:event_lblConfigMouseClicked

    private void menuoptCerrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuoptCerrarActionPerformed
        Loggin lg = new Loggin();
        lg.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_menuoptCerrarActionPerformed

    private void lblHogarMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblHogarMouseEntered
       lblHogar.setFont(lblHogar.getFont().deriveFont(Font.BOLD));
    }//GEN-LAST:event_lblHogarMouseEntered

    private void lblHogarMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblHogarMouseExited
        lblHogar.setFont(lblHogar.getFont().deriveFont(Font.PLAIN));
    }//GEN-LAST:event_lblHogarMouseExited

    private void lblTutoresMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblTutoresMouseEntered
        lblTutores.setFont(lblTutores.getFont().deriveFont(Font.BOLD));
    }//GEN-LAST:event_lblTutoresMouseEntered

    private void lblTutoresMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblTutoresMouseExited
        lblTutores.setFont(lblTutores.getFont().deriveFont(Font.PLAIN));
    }//GEN-LAST:event_lblTutoresMouseExited

    private void lblMateriasMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblMateriasMouseEntered
        lblMaterias.setFont(lblMaterias.getFont().deriveFont(Font.BOLD));
    }//GEN-LAST:event_lblMateriasMouseEntered

    private void lblMateriasMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblMateriasMouseExited
        lblMaterias.setFont(lblMaterias.getFont().deriveFont(Font.PLAIN));
    }//GEN-LAST:event_lblMateriasMouseExited

    private void lblHogarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblHogarMouseClicked
         this.dispose();
        MenuPrincipalAdmin mp = new MenuPrincipalAdmin();
        mp.asignarUsuario(usuario);
        mp.setVisible(true);
    }//GEN-LAST:event_lblHogarMouseClicked

    private void lblTutoresMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblTutoresMouseClicked
       this.dispose();
        VentanaTutores vt =new VentanaTutores();
        vt.asignarUsuario(usuario);
        vt.setVisible(true);
    }//GEN-LAST:event_lblTutoresMouseClicked

    private void lblMateriasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblMateriasMouseClicked
       this.dispose();
        VentanaMaterias vm =new VentanaMaterias();
        vm.asignarUsuario(usuario);
        vm.setVisible(true);
    }//GEN-LAST:event_lblMateriasMouseClicked

    private void panelTablaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panelTablaMouseClicked

    }//GEN-LAST:event_panelTablaMouseClicked

    private void tablaDatosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaDatosMouseClicked
        obtenerAlumnoSeleccionado();
        btnAsignar.setEnabled(true);
        btnDeseleccionar.setEnabled(true);
        btnActualizar.setEnabled(true);
        btnEliminar.setEnabled(true);
    }//GEN-LAST:event_tablaDatosMouseClicked

    private void btnDeseleccionarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeseleccionarActionPerformed
        tablaDatos.clearSelection();
        btnAsignar.setEnabled(false);
        btnDeseleccionar.setEnabled(false);
    }//GEN-LAST:event_btnDeseleccionarActionPerformed

    private void btnAsignarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAsignarActionPerformed
        obtenerAlumnoSeleccionado();
        materias.asignarAlumno(alumnoSeleccionado);
        materias.setVisible(true);
        materias.getmateriaSeleccionada();
        System.out.println(materias.getmateriaSeleccionada());
    }//GEN-LAST:event_btnAsignarActionPerformed

    private void txtnumControlKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtnumControlKeyTyped
        char c = evt.getKeyChar();
        if(!Character.isDigit(c) ){
            evt.consume();
            //JOptionPane.showMessageDialog(null,"Solo ingresa numeros");
        }
    }//GEN-LAST:event_txtnumControlKeyTyped

    private void btnRegistroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegistroActionPerformed
    agregar.setVisible(true);
    modelon.fireTableDataChanged();
    }//GEN-LAST:event_btnRegistroActionPerformed

    private void btnAlumnosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAlumnosActionPerformed
        cargarDatos();
    }//GEN-LAST:event_btnAlumnosActionPerformed

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
        buscarAlumno();
    }//GEN-LAST:event_btnBuscarActionPerformed

    private void menuCrearAdminMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menuCrearAdminMouseClicked
        
    }//GEN-LAST:event_menuCrearAdminMouseClicked

    private void menuCrearAdminActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuCrearAdminActionPerformed
        AgregarAdmin ad = new AgregarAdmin(null,true);
       ad.setVisible(true);
    }//GEN-LAST:event_menuCrearAdminActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        obtenerAlumnoSeleccionado();
        if (alumnoSeleccionado != null) {
            int confirm = JOptionPane.showConfirmDialog(this, "¿Está seguro de que desea eliminar el alumno seleccionado?", "Confirmar eliminación", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                try {
                    if (alumnos.eliminarAlumno(alumnoSeleccionado.getNumControl())) {
                        JOptionPane.showMessageDialog(this, "Alumno eliminado correctamente.");
                        cargarDatos();
                    } else {
                        JOptionPane.showMessageDialog(this, "Error al eliminar el alumno.");
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                    JOptionPane.showMessageDialog(this, "Error al eliminar el alumno: " + e.getMessage());
                }
            }
        }
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarActionPerformed
        obtenerAlumnoSeleccionado();
        if (alumnoSeleccionado != null) {
            int seleccion = tablaDatos.getSelectedRow();
            if (seleccion != -1) {
                alumnoSeleccionado.setNombre((String) tablaDatos.getValueAt(seleccion, 1));
                alumnoSeleccionado.setAPaterno((String) tablaDatos.getValueAt(seleccion, 2));
                alumnoSeleccionado.setAMaterno((String) tablaDatos.getValueAt(seleccion, 3));

                // Convertir el valor de la celda a int
                Object semestreValue = tablaDatos.getValueAt(seleccion, 4);
                int semestre;
                if (semestreValue instanceof Integer) {
                    semestre = (Integer) semestreValue;
                } else if (semestreValue instanceof String) {
                    semestre = Integer.parseInt((String) semestreValue);
                } else {
                    JOptionPane.showMessageDialog(this, "El valor del semestre no es válido.");
                    return;
                }
                alumnoSeleccionado.setSemestre(semestre);

                alumnoSeleccionado.setCarrera((String) tablaDatos.getValueAt(seleccion, 5));
                alumnoSeleccionado.setCorreo((String) tablaDatos.getValueAt(seleccion, 6));
                try {
                    if (alumnos.actualizarAlumno(alumnoSeleccionado)) {
                        JOptionPane.showMessageDialog(this, "Alumno actualizado correctamente.");
                        cargarDatos();
                    } else {
                        JOptionPane.showMessageDialog(this, "Error al actualizar el alumno.");
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                    JOptionPane.showMessageDialog(this, "Error al actualizar el alumno: " + e.getMessage());
                }
            }
        }
    }//GEN-LAST:event_btnActualizarActionPerformed

    private void estaSeleccionado(){
        
    }
    
    private void menuBarrasMouseClicked(MouseEvent e) {
        lblmenuBarras.setVisible(false);
        panelMenu.setVisible(true);
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VentanaAlumnos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VentanaAlumnos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VentanaAlumnos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VentanaAlumnos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VentanaAlumnos().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnActualizar;
    private javax.swing.JButton btnAlumnos;
    private javax.swing.JButton btnAsignar;
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnDeseleccionar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnRegistro;
    private javax.swing.Box.Filler filler1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JLabel lblConfig;
    private javax.swing.JLabel lblHogar;
    private javax.swing.JLabel lblImagenAdorno;
    private javax.swing.JLabel lblMaterias;
    private javax.swing.JLabel lblRetroceder;
    private javax.swing.JLabel lblTutores;
    private javax.swing.JLabel lblUsuario;
    private javax.swing.JLabel lblnumControl;
    private javax.swing.JMenuItem menuCrearAdmin;
    private javax.swing.JPopupMenu menuOpciones;
    private javax.swing.JMenuItem menuoptCerrar;
    private javax.swing.JPanel panelAlumnos;
    private javax.swing.JPanel panelBotones;
    private javax.swing.JPanel panelBusqueda;
    private javax.swing.JPanel panelFondo;
    private javax.swing.JPanel panelMenu;
    private javax.swing.JScrollPane panelTabla;
    private javax.swing.JPanel paneltitulo;
    private javax.swing.JPopupMenu.Separator separador1;
    private javax.swing.JTable tablaDatos;
    private javax.swing.JTextField txtnumControl;
    // End of variables declaration//GEN-END:variables
}
