/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */
package paquetegrafico;

import Modelo.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.NoSuchProviderException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import org.apache.pdfbox.Loader;
import org.apache.pdfbox.pdfwriter.compress.CompressParameters;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.font.Standard14Fonts;
/**
 *
 * @author salin
 */
public class AsignarMaterias extends javax.swing.JDialog {
    private int n;
    private int capacidad;
    private Alumno alumno;
    private AccesoAlumnos alumnos;
    private Materia materia, materiaSeleccionada;
    private AccesoMaterias materias;
    private List<Materia> listaMaterias;
    private List<Materia> listaMaterias2;
    private List<Materia> listaMaterias3;
    private Materia[] arregloMaterias;
    private Confirmacion confi;
    private Curso curso;
    private AccesoCursos cursos;
    private Tutor tutor;
    private AccesoTutores tutores;
    private boolean existe;
    private String correoMensajero;
    private String contraCorreo;
    private String destinatario, asunto, contenido;
    private Properties mProperties;
    private Session mSession;
    private MimeMessage mCorreo;
    private boolean hecho;
    Alumno alumnoMat;
     private File mArchivoAdjuntos;
    private String nombres_archivos;
   
    /**
     * Creates new form Materia
     */
    public AsignarMaterias(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        alumnoMat = new Alumno();
        mProperties = new Properties();
        materiaSeleccionada = new Materia();
        tutor = new Tutor();
        tutores = new AccesoTutores();
        curso = new Curso();
        cursos = new AccesoCursos();
        confi = new Confirmacion(null, true);
        alumnos = new AccesoAlumnos();
        materia = new Materia();
        materias = new AccesoMaterias();
        n=0;
        capacidad = 10;
        existe = false;
        correoMensajero = "matadamasjoel93@gmail.com";
        contraCorreo = "lquexyskadyhrotb";
        hecho = false;
    }
    
   
    
    
    
    public void asignarAlumno(Alumno alumno){
        this.alumno = alumno;
        jLabel1.setText(alumno.getNombre());
        cargarMaterias();
        mostrarMaterias();
    }
    
     private void crearCorreo(Alumno alum){
        destinatario = alum.getCorreo();
        asunto = "Registro en el Sistema de Tutorias";
        contenido = "Estimado/a " + alum.getNombre() + ",\n\n" + "Nos complace darte la bienvenida al Sistema de Tutorías."+" Estamos emocionados de que te unas a nuestra comunidad, "+"donde tendrás la oportunidad de aprender, crecer y conectarte con tutores apasionados.";
        
        mProperties.put("mail.smtp.host", "smtp.gmail.com");
        mProperties.put("mail.smtp.ssl.trust", "smtp.gmail.com");
        mProperties.setProperty("mail.smtp.starttls.enable", "true");
        mProperties.setProperty("mail.smtp.port", "587");
        mProperties.setProperty("mail.smtp.user",correoMensajero);
        mProperties.setProperty("mail.smtp.ssl.protocols", "TLSv1.2");
        mProperties.setProperty("mail.smtp.auth", "true");
        
        mSession = Session.getDefaultInstance(mProperties);
        
        
        try {
        MimeMultipart mElementosCorreo = new MimeMultipart();
        
        // Contenido del correo
        MimeBodyPart mContenido = new MimeBodyPart();
        mContenido.setContent(contenido, "text/html; charset=utf-8");
        mElementosCorreo.addBodyPart(mContenido);
        
        // Agregar archivos adjuntos
        MimeBodyPart mAdjuntos = new MimeBodyPart();
        String pdfFilePath = "C:\\Users\\salin\\OneDrive\\Documentos\\Tec\\RecibirPDF\\RegistroTutorias"+alum.getNombre()+".pdf"; // Especifica la ruta del PDF aquí
        File pdfFile = new File(pdfFilePath);
        
        if (pdfFile.exists()) {
            mAdjuntos.setDataHandler(new DataHandler(new FileDataSource(pdfFile.getAbsolutePath())));
            mAdjuntos.setFileName(pdfFile.getName());
            mElementosCorreo.addBodyPart(mAdjuntos);
        } else {
            System.out.println("El archivo PDF no existe en la ruta especificada.");
        }
        
        mCorreo = new MimeMessage(mSession);
        mCorreo.setFrom(new InternetAddress(correoMensajero));
        mCorreo.setRecipient(Message.RecipientType.TO, new InternetAddress(destinatario));
        mCorreo.setSubject(asunto);
        mCorreo.setContent(mElementosCorreo);
            
            
                     
            
        } catch (AddressException ex) {
            Logger.getLogger(AsignarMaterias.class.getName()).log(Level.SEVERE, null, ex);
        } catch (MessagingException ex) {
            Logger.getLogger(AsignarMaterias.class.getName()).log(Level.SEVERE, null, ex);
        }
     }
    
    private void sendEmail(){
        try {
            Transport mTransport = mSession.getTransport("smtp");
            mTransport.connect(correoMensajero, contraCorreo);
            mTransport.sendMessage(mCorreo, mCorreo.getRecipients(Message.RecipientType.TO));
            mTransport.close();
            hecho = true;
            JOptionPane.showMessageDialog(null, "Correo enviado");
            
        } catch (NoSuchProviderException ex) {
            Logger.getLogger(AsignarMaterias.class.getName()).log(Level.SEVERE, null, ex);
        } catch (MessagingException ex) {
            Logger.getLogger(AsignarMaterias.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
     private void cargarMaterias() {
         try {
            String carreraAlumno = alumno.getCarrera();
            int semestreAlumno = alumno.getSemestre();
            listaMaterias = materias.getMateriasFiltro(carreraAlumno, semestreAlumno);
            arregloMaterias = listaMaterias.toArray(new Materia[0]);
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al cargar las materias: " + e.getMessage());
        }
    }
    


     
     private void mostrarMaterias() {
   // List<Materia> listaMaterias = new ArrayList<>();
    //List<Materia> listaMateria2 = new ArrayList<>();
    //List<Materia> listaMateria3 = new ArrayList<>();

    try {
        String carreraAlumno = alumno.getCarrera();
        int semestreAlumno = alumno.getSemestre();

        listaMaterias = materias.getMateriasFiltro(carreraAlumno, semestreAlumno );
        if (semestreAlumno > 1) {
            listaMaterias2 = materias.getMateriasFiltro(carreraAlumno, semestreAlumno - 1);
        }
        if (semestreAlumno > 2) {
            listaMaterias3 = materias.getMateriasFiltro(carreraAlumno, semestreAlumno - 2);
        }

        // Configurar materias para el primer semestre
        if (semestreAlumno <= 1) {
            setMateriasLabels(listaMaterias, lblMat1, lblMat2, lblMat3);
            setPanelsVisibility(false);
            setPanelsVisibility(false, 4,5,6);
            setPanelsVisibility(false, 7,8,9);
        } else if (semestreAlumno == 2) {
            setMateriasLabels(listaMaterias2, lblMat4, lblMat5, lblMat6);
            setMateriasLabels(listaMaterias, lblMat1, lblMat2, lblMat3);
            setPanelsVisibility(true, 4, 5, 6);
            setPanelsVisibility(false,7,8,9);
        } else {
            setMateriasLabels(listaMaterias3, lblMat7, lblMat8, lblMat9);
            setMateriasLabels(listaMaterias2, lblMat4, lblMat5, lblMat6);
            setMateriasLabels(listaMaterias, lblMat1, lblMat2, lblMat3);
            setPanelsVisibility(true);
            setPanelsVisibility(true, 4, 5, 6);
            setPanelsVisibility(true,7,8,9);
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
}

// Método auxiliar para establecer el texto de las etiquetas
private void setMateriasLabels(List<Materia> lista, JLabel... labels) {
    for (int i = 0; i < labels.length; i++) {
        if (i < lista.size()) {
            labels[i].setText(lista.get(i).getNombre());
        } else {
            labels[i].setText("");
        }
    }
}

// Método auxiliar para configurar la visibilidad de los paneles
private void setPanelsVisibility(boolean visible, int... panelIndices) {
    for (int index : panelIndices) {
        switch (index) {
            case 4: panelMateria4.setVisible(visible); break;
            case 5: panelMateria5.setVisible(visible); break;
            case 6: panelMateria6.setVisible(visible); break;
            case 7: panelMateria7.setVisible(visible); break;
            case 8: panelMateria8.setVisible(visible); break;
            case 9: panelMateria9.setVisible(visible); break;
        }
    }
}

     
     
     private void asignarMateriaDesdeLabel(Materia materia) {
    try{
         int idMateria = materia.getId();
    System.out.println(""+materia.getNombre());
    if(existeCurso(idMateria)){
       curso = cursos.obtenerCursoPorMateria(idMateria);
       alumnos.asignarMateria(alumno.getNumControl(), idMateria);
       materiaSeleccionada = materias.obtenerMateria(idMateria);
       tutor = tutores.obtenerTutorconID(curso.getIdTutor());
       String nombreTutor = tutor.getAPaterno() + " " + tutor.getAMaterno() + " " + tutor.getNombre();
       ModificarPDF(materiaSeleccionada.getNombre(), nombreTutor, curso.getAula(), String.valueOf(curso.getHoraInicio()), String.valueOf(curso.getHoraFin()), alumno.getNombre());
    }}catch(SQLException e){}
}

     
     private boolean existeCurso(int idMateria) throws SQLException {
    Curso curso = cursos.obtenerCursoPorMateria(idMateria);
    if(curso != null){
        existe = true;
    }
    return curso != null;
}

     
     public void ModificarPDF(String nombre, String tutor, String aula, String horaInicio, String horaFin,String nombreAlumno){
         String pdfPath = "C:\\Users\\salin\\OneDrive\\Documentos\\Tec\\PdfProyecto\\Informacion.pdf"; // Ruta al PDF que deseas modificar
        String outputPath = "C:\\Users\\salin\\OneDrive\\Documentos\\Tec\\RecibirPDF\\RegistroTutorias"+nombreAlumno+".pdf"; // Ruta donde se guardará el PDF modificado

        try (PDDocument document = Loader.loadPDF(new File(pdfPath))) {
            // Suponemos que deseas modificar la primera página
            PDPage page = document.getPage(0);

            // Crear un flujo de contenido para la página
            try (PDPageContentStream contentStream = new PDPageContentStream(document, page, PDPageContentStream.AppendMode.APPEND, true, true)) {
                // Configura la fuente y el tamaño
                contentStream.setFont(new PDType1Font(Standard14Fonts.FontName.HELVETICA), 10);
                
                contentStream.beginText();
                contentStream.newLineAtOffset(340, 288); // Ajusta la posición del texto
                contentStream.showText(nombre);
                contentStream.endText();
                
                contentStream.beginText();
                contentStream.newLineAtOffset(340, 253); // Ajusta la posición del texto
                contentStream.showText(tutor);
                contentStream.endText();
                
               contentStream.beginText();
                contentStream.newLineAtOffset(340, 218); // Ajusta la posición del texto
                contentStream.showText(aula);
                contentStream.endText();
                
                contentStream.beginText();
                contentStream.newLineAtOffset(340, 183); // Ajusta la posición del texto
                contentStream.showText(horaInicio);
                contentStream.endText();
                
                contentStream.beginText();
                contentStream.newLineAtOffset(340, 148); // Ajusta la posición del texto
                contentStream.showText(horaFin);
                contentStream.endText();
            }

            // Guardar el documento modificado
            document.save(outputPath, CompressParameters.NO_COMPRESSION);
            System.out.println("PDF modificado y guardado en: " + outputPath);
        } catch (IOException e) {
            e.printStackTrace();
        }
     }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panelFondo = new javax.swing.JPanel();
        panelTItulo = new javax.swing.JPanel();
        lblTitulo = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        panelOpciones = new javax.swing.JPanel();
        panelMateria1 = new javax.swing.JPanel();
        lblimgMat1 = new javax.swing.JLabel();
        lblMat1 = new javax.swing.JLabel();
        panelMateria2 = new javax.swing.JPanel();
        lblimgMat2 = new javax.swing.JLabel();
        lblMat2 = new javax.swing.JLabel();
        panelMateria3 = new javax.swing.JPanel();
        lblimgMat3 = new javax.swing.JLabel();
        lblMat3 = new javax.swing.JLabel();
        panelMateria4 = new javax.swing.JPanel();
        lblimgMat4 = new javax.swing.JLabel();
        lblMat4 = new javax.swing.JLabel();
        panelMateria5 = new javax.swing.JPanel();
        lblimgMat5 = new javax.swing.JLabel();
        lblMat5 = new javax.swing.JLabel();
        panelMateria6 = new javax.swing.JPanel();
        lblimgMat6 = new javax.swing.JLabel();
        lblMat6 = new javax.swing.JLabel();
        panelMateria7 = new javax.swing.JPanel();
        lblimgMat7 = new javax.swing.JLabel();
        lblMat7 = new javax.swing.JLabel();
        panelMateria8 = new javax.swing.JPanel();
        lblimgMat8 = new javax.swing.JLabel();
        lblMat8 = new javax.swing.JLabel();
        panelMateria9 = new javax.swing.JPanel();
        lblimgMat9 = new javax.swing.JLabel();
        lblMat9 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Seleccion de materias");
        setResizable(false);

        panelFondo.setBackground(new java.awt.Color(255, 255, 255));

        panelTItulo.setBackground(new java.awt.Color(0, 0, 102));

        lblTitulo.setFont(new java.awt.Font("Segoe UI Semibold", 1, 20)); // NOI18N
        lblTitulo.setForeground(new java.awt.Color(255, 255, 255));
        lblTitulo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTitulo.setText("Asignación de Materia");

        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("nombre");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Alumno:");

        javax.swing.GroupLayout panelTItuloLayout = new javax.swing.GroupLayout(panelTItulo);
        panelTItulo.setLayout(panelTItuloLayout);
        panelTItuloLayout.setHorizontalGroup(
            panelTItuloLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelTItuloLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelTItuloLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblTitulo, javax.swing.GroupLayout.DEFAULT_SIZE, 436, Short.MAX_VALUE)
                    .addGroup(panelTItuloLayout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel1)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        panelTItuloLayout.setVerticalGroup(
            panelTItuloLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelTItuloLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblTitulo)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelTItuloLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2))
                .addContainerGap(7, Short.MAX_VALUE))
        );

        panelOpciones.setBackground(new java.awt.Color(255, 255, 255));
        panelOpciones.setLayout(new java.awt.GridLayout(3, 3));

        panelMateria1.setBackground(new java.awt.Color(255, 255, 255));
        panelMateria1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panelMateria1MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                panelMateria1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                panelMateria1MouseExited(evt);
            }
        });

        lblimgMat1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblimgMat1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/algebralineal.png"))); // NOI18N
        lblimgMat1.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        lblimgMat1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblimgMat1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblimgMat1.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);

        lblMat1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblMat1.setText("Materia 1");

        javax.swing.GroupLayout panelMateria1Layout = new javax.swing.GroupLayout(panelMateria1);
        panelMateria1.setLayout(panelMateria1Layout);
        panelMateria1Layout.setHorizontalGroup(
            panelMateria1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelMateria1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblMat1, javax.swing.GroupLayout.DEFAULT_SIZE, 137, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(panelMateria1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panelMateria1Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(lblimgMat1, javax.swing.GroupLayout.DEFAULT_SIZE, 137, Short.MAX_VALUE)
                    .addContainerGap()))
        );
        panelMateria1Layout.setVerticalGroup(
            panelMateria1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelMateria1Layout.createSequentialGroup()
                .addContainerGap(107, Short.MAX_VALUE)
                .addComponent(lblMat1)
                .addContainerGap())
            .addGroup(panelMateria1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panelMateria1Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(lblimgMat1)
                    .addContainerGap(29, Short.MAX_VALUE)))
        );

        panelOpciones.add(panelMateria1);

        panelMateria2.setBackground(new java.awt.Color(255, 255, 255));
        panelMateria2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panelMateria2MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                panelMateria2MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                panelMateria2MouseExited(evt);
            }
        });

        lblimgMat2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblimgMat2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/calculointegral.png"))); // NOI18N
        lblimgMat2.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        lblimgMat2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblimgMat2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblimgMat2.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);

        lblMat2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblMat2.setText("Materia 2");

        javax.swing.GroupLayout panelMateria2Layout = new javax.swing.GroupLayout(panelMateria2);
        panelMateria2.setLayout(panelMateria2Layout);
        panelMateria2Layout.setHorizontalGroup(
            panelMateria2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelMateria2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblMat2, javax.swing.GroupLayout.DEFAULT_SIZE, 137, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(panelMateria2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panelMateria2Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(lblimgMat2, javax.swing.GroupLayout.DEFAULT_SIZE, 137, Short.MAX_VALUE)
                    .addContainerGap()))
        );
        panelMateria2Layout.setVerticalGroup(
            panelMateria2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelMateria2Layout.createSequentialGroup()
                .addContainerGap(107, Short.MAX_VALUE)
                .addComponent(lblMat2)
                .addContainerGap())
            .addGroup(panelMateria2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panelMateria2Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(lblimgMat2)
                    .addContainerGap(29, Short.MAX_VALUE)))
        );

        panelOpciones.add(panelMateria2);

        panelMateria3.setBackground(new java.awt.Color(255, 255, 255));
        panelMateria3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panelMateria3MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                panelMateria3MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                panelMateria3MouseExited(evt);
            }
        });

        lblimgMat3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblimgMat3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/calculovectorial.png"))); // NOI18N
        lblimgMat3.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        lblimgMat3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblimgMat3.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblimgMat3.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);

        lblMat3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblMat3.setText("Materia 3");

        javax.swing.GroupLayout panelMateria3Layout = new javax.swing.GroupLayout(panelMateria3);
        panelMateria3.setLayout(panelMateria3Layout);
        panelMateria3Layout.setHorizontalGroup(
            panelMateria3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelMateria3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblMat3, javax.swing.GroupLayout.DEFAULT_SIZE, 137, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(panelMateria3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panelMateria3Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(lblimgMat3, javax.swing.GroupLayout.DEFAULT_SIZE, 137, Short.MAX_VALUE)
                    .addContainerGap()))
        );
        panelMateria3Layout.setVerticalGroup(
            panelMateria3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelMateria3Layout.createSequentialGroup()
                .addContainerGap(107, Short.MAX_VALUE)
                .addComponent(lblMat3)
                .addContainerGap())
            .addGroup(panelMateria3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panelMateria3Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(lblimgMat3)
                    .addContainerGap(29, Short.MAX_VALUE)))
        );

        panelOpciones.add(panelMateria3);

        panelMateria4.setBackground(new java.awt.Color(255, 255, 255));
        panelMateria4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panelMateria4MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                panelMateria4MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                panelMateria4MouseExited(evt);
            }
        });

        lblimgMat4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblimgMat4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/ecuaciones.png"))); // NOI18N
        lblimgMat4.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        lblimgMat4.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblimgMat4.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblimgMat4.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);

        lblMat4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblMat4.setText("Materia 4");

        javax.swing.GroupLayout panelMateria4Layout = new javax.swing.GroupLayout(panelMateria4);
        panelMateria4.setLayout(panelMateria4Layout);
        panelMateria4Layout.setHorizontalGroup(
            panelMateria4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelMateria4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblMat4, javax.swing.GroupLayout.DEFAULT_SIZE, 137, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(panelMateria4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panelMateria4Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(lblimgMat4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addContainerGap()))
        );
        panelMateria4Layout.setVerticalGroup(
            panelMateria4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelMateria4Layout.createSequentialGroup()
                .addContainerGap(107, Short.MAX_VALUE)
                .addComponent(lblMat4)
                .addContainerGap())
            .addGroup(panelMateria4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panelMateria4Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(lblimgMat4)
                    .addContainerGap(29, Short.MAX_VALUE)))
        );

        panelOpciones.add(panelMateria4);

        panelMateria5.setBackground(new java.awt.Color(255, 255, 255));
        panelMateria5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panelMateria5MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                panelMateria5MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                panelMateria5MouseExited(evt);
            }
        });

        lblimgMat5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblimgMat5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/bda.png"))); // NOI18N
        lblimgMat5.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        lblimgMat5.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblimgMat5.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblimgMat5.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);

        lblMat5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblMat5.setText("Materia 5");

        javax.swing.GroupLayout panelMateria5Layout = new javax.swing.GroupLayout(panelMateria5);
        panelMateria5.setLayout(panelMateria5Layout);
        panelMateria5Layout.setHorizontalGroup(
            panelMateria5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelMateria5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblMat5, javax.swing.GroupLayout.DEFAULT_SIZE, 137, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(panelMateria5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panelMateria5Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(lblimgMat5, javax.swing.GroupLayout.DEFAULT_SIZE, 137, Short.MAX_VALUE)
                    .addContainerGap()))
        );
        panelMateria5Layout.setVerticalGroup(
            panelMateria5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelMateria5Layout.createSequentialGroup()
                .addContainerGap(107, Short.MAX_VALUE)
                .addComponent(lblMat5)
                .addContainerGap())
            .addGroup(panelMateria5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panelMateria5Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(lblimgMat5)
                    .addContainerGap(29, Short.MAX_VALUE)))
        );

        panelOpciones.add(panelMateria5);

        panelMateria6.setBackground(new java.awt.Color(255, 255, 255));
        panelMateria6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panelMateria6MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                panelMateria6MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                panelMateria6MouseExited(evt);
            }
        });

        lblimgMat6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblimgMat6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/topicos.png"))); // NOI18N
        lblimgMat6.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        lblimgMat6.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblimgMat6.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblimgMat6.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);

        lblMat6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblMat6.setText("Materia 6");

        javax.swing.GroupLayout panelMateria6Layout = new javax.swing.GroupLayout(panelMateria6);
        panelMateria6.setLayout(panelMateria6Layout);
        panelMateria6Layout.setHorizontalGroup(
            panelMateria6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelMateria6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblMat6, javax.swing.GroupLayout.DEFAULT_SIZE, 137, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(panelMateria6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panelMateria6Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(lblimgMat6, javax.swing.GroupLayout.DEFAULT_SIZE, 137, Short.MAX_VALUE)
                    .addContainerGap()))
        );
        panelMateria6Layout.setVerticalGroup(
            panelMateria6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelMateria6Layout.createSequentialGroup()
                .addContainerGap(107, Short.MAX_VALUE)
                .addComponent(lblMat6)
                .addContainerGap())
            .addGroup(panelMateria6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panelMateria6Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(lblimgMat6)
                    .addContainerGap(29, Short.MAX_VALUE)))
        );

        panelOpciones.add(panelMateria6);

        panelMateria7.setBackground(new java.awt.Color(255, 255, 255));
        panelMateria7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panelMateria7MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                panelMateria7MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                panelMateria7MouseExited(evt);
            }
        });

        lblimgMat7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblimgMat7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/contabilidad.png"))); // NOI18N
        lblimgMat7.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        lblimgMat7.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblimgMat7.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblimgMat7.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);

        lblMat7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblMat7.setText("Materia 7");

        javax.swing.GroupLayout panelMateria7Layout = new javax.swing.GroupLayout(panelMateria7);
        panelMateria7.setLayout(panelMateria7Layout);
        panelMateria7Layout.setHorizontalGroup(
            panelMateria7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelMateria7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblMat7, javax.swing.GroupLayout.DEFAULT_SIZE, 137, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(panelMateria7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panelMateria7Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(lblimgMat7, javax.swing.GroupLayout.DEFAULT_SIZE, 137, Short.MAX_VALUE)
                    .addContainerGap()))
        );
        panelMateria7Layout.setVerticalGroup(
            panelMateria7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelMateria7Layout.createSequentialGroup()
                .addContainerGap(107, Short.MAX_VALUE)
                .addComponent(lblMat7)
                .addContainerGap())
            .addGroup(panelMateria7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panelMateria7Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(lblimgMat7)
                    .addContainerGap(29, Short.MAX_VALUE)))
        );

        panelOpciones.add(panelMateria7);

        panelMateria8.setBackground(new java.awt.Color(255, 255, 255));
        panelMateria8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panelMateria8MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                panelMateria8MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                panelMateria8MouseExited(evt);
            }
        });

        lblimgMat8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblimgMat8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/probabilidad.png"))); // NOI18N
        lblimgMat8.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        lblimgMat8.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblimgMat8.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblimgMat8.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);

        lblMat8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblMat8.setText("Materia 8");

        javax.swing.GroupLayout panelMateria8Layout = new javax.swing.GroupLayout(panelMateria8);
        panelMateria8.setLayout(panelMateria8Layout);
        panelMateria8Layout.setHorizontalGroup(
            panelMateria8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelMateria8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblMat8, javax.swing.GroupLayout.DEFAULT_SIZE, 137, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(panelMateria8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panelMateria8Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(lblimgMat8, javax.swing.GroupLayout.DEFAULT_SIZE, 137, Short.MAX_VALUE)
                    .addContainerGap()))
        );
        panelMateria8Layout.setVerticalGroup(
            panelMateria8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelMateria8Layout.createSequentialGroup()
                .addContainerGap(107, Short.MAX_VALUE)
                .addComponent(lblMat8)
                .addContainerGap())
            .addGroup(panelMateria8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panelMateria8Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(lblimgMat8)
                    .addContainerGap(29, Short.MAX_VALUE)))
        );

        panelOpciones.add(panelMateria8);

        panelMateria9.setBackground(new java.awt.Color(255, 255, 255));
        panelMateria9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panelMateria9MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                panelMateria9MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                panelMateria9MouseExited(evt);
            }
        });

        lblimgMat9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblimgMat9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/fisica.png"))); // NOI18N
        lblimgMat9.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        lblimgMat9.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblimgMat9.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblimgMat9.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);

        lblMat9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblMat9.setText("Materia 9");

        javax.swing.GroupLayout panelMateria9Layout = new javax.swing.GroupLayout(panelMateria9);
        panelMateria9.setLayout(panelMateria9Layout);
        panelMateria9Layout.setHorizontalGroup(
            panelMateria9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelMateria9Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblMat9, javax.swing.GroupLayout.DEFAULT_SIZE, 137, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(panelMateria9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panelMateria9Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(lblimgMat9, javax.swing.GroupLayout.DEFAULT_SIZE, 137, Short.MAX_VALUE)
                    .addContainerGap()))
        );
        panelMateria9Layout.setVerticalGroup(
            panelMateria9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelMateria9Layout.createSequentialGroup()
                .addContainerGap(107, Short.MAX_VALUE)
                .addComponent(lblMat9)
                .addContainerGap())
            .addGroup(panelMateria9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panelMateria9Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(lblimgMat9)
                    .addContainerGap(29, Short.MAX_VALUE)))
        );

        panelOpciones.add(panelMateria9);

        javax.swing.GroupLayout panelFondoLayout = new javax.swing.GroupLayout(panelFondo);
        panelFondo.setLayout(panelFondoLayout);
        panelFondoLayout.setHorizontalGroup(
            panelFondoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelTItulo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(panelOpciones, javax.swing.GroupLayout.DEFAULT_SIZE, 448, Short.MAX_VALUE)
        );
        panelFondoLayout.setVerticalGroup(
            panelFondoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelFondoLayout.createSequentialGroup()
                .addComponent(panelTItulo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(panelOpciones, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelFondo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelFondo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void panelMateria2MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panelMateria2MouseEntered
        panelMateria2.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
    }//GEN-LAST:event_panelMateria2MouseEntered

    private void panelMateria1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panelMateria1MouseEntered
       panelMateria1.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
       //lblNumeroCupo.setText(""+materia.getCapacidad());
    }//GEN-LAST:event_panelMateria1MouseEntered

    private void panelMateria1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panelMateria1MouseExited
         panelMateria1.setBorder(null);
    }//GEN-LAST:event_panelMateria1MouseExited

    private void panelMateria2MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panelMateria2MouseExited
       panelMateria2.setBorder(null);
    }//GEN-LAST:event_panelMateria2MouseExited

    private void panelMateria3MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panelMateria3MouseEntered
        panelMateria3.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
    }//GEN-LAST:event_panelMateria3MouseEntered

    private void panelMateria3MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panelMateria3MouseExited
       panelMateria3.setBorder(null);
    }//GEN-LAST:event_panelMateria3MouseExited

    private void panelMateria4MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panelMateria4MouseEntered
        panelMateria4.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
    }//GEN-LAST:event_panelMateria4MouseEntered

    private void panelMateria4MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panelMateria4MouseExited
        panelMateria4.setBorder(null);
    }//GEN-LAST:event_panelMateria4MouseExited

    private void panelMateria5MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panelMateria5MouseEntered
       panelMateria5.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
    }//GEN-LAST:event_panelMateria5MouseEntered

    private void panelMateria5MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panelMateria5MouseExited
       panelMateria5.setBorder(null);
    }//GEN-LAST:event_panelMateria5MouseExited

    private void panelMateria6MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panelMateria6MouseEntered
        panelMateria6.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
    }//GEN-LAST:event_panelMateria6MouseEntered

    private void panelMateria6MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panelMateria6MouseExited
       panelMateria6.setBorder(null);
    }//GEN-LAST:event_panelMateria6MouseExited

    private void panelMateria7MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panelMateria7MouseEntered
        panelMateria7.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
    }//GEN-LAST:event_panelMateria7MouseEntered

    private void panelMateria7MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panelMateria7MouseExited
        panelMateria7.setBorder(null);
    }//GEN-LAST:event_panelMateria7MouseExited

    private void panelMateria8MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panelMateria8MouseEntered
       panelMateria8.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
    }//GEN-LAST:event_panelMateria8MouseEntered

    private void panelMateria8MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panelMateria8MouseExited
        panelMateria8.setBorder(null);
    }//GEN-LAST:event_panelMateria8MouseExited

    private void panelMateria9MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panelMateria9MouseEntered
       panelMateria9.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
    }//GEN-LAST:event_panelMateria9MouseEntered

    private void panelMateria9MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panelMateria9MouseExited
        panelMateria9.setBorder(null);
    }//GEN-LAST:event_panelMateria9MouseExited

    
    private void panelMateria1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panelMateria1MouseClicked
       try{
        int idMateria = listaMaterias.get(0).getId();
        
        //alumnoMat = alumnos.obtenerAlumnoPorIdMateria(idMateria);
        
       System.out.println(""+idMateria);
       existeCurso(idMateria);}
       catch(SQLException e){}
        if(!existe){
            JOptionPane.showMessageDialog(null, "No tiene un curso asignado");
        }else{
        n=1;
        confi.setVisible(true);
        if(!confi.eleccion()){
           asignarMateriaDesdeLabel(listaMaterias.get(0));
            crearCorreo(alumno);
            sendEmail();
            
            JOptionPane.showMessageDialog(null, "Materia asignada exitosamente | correo enviado");
        this.dispose();}
            existe = false;
        }
    }//GEN-LAST:event_panelMateria1MouseClicked

    private void panelMateria2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panelMateria2MouseClicked
       try{
        int idMateria = listaMaterias.get(1).getId();
        
        //alumnoMat = alumnos.obtenerAlumnoPorIdMateria(idMateria);
        
       System.out.println(""+idMateria);
       existeCurso(idMateria);}
       catch(SQLException e){}
        if(!existe){
            JOptionPane.showMessageDialog(null, "No tiene un curso asignado");
        }else{
        n=2;
        confi.setVisible(true);
        if(!confi.eleccion()){
            asignarMateriaDesdeLabel(listaMaterias.get(1));
            crearCorreo(alumno);
            sendEmail();
            
            JOptionPane.showMessageDialog(null, "Materia asignada exitosamente | correo enviado");
        this.dispose();}
            existe = false;
        }
    }//GEN-LAST:event_panelMateria2MouseClicked

    private void panelMateria3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panelMateria3MouseClicked
        try{
        int idMateria = listaMaterias.get(2).getId();
        
       // alumnoMat = alumnos.obtenerAlumnoPorIdMateria(idMateria);
        
       System.out.println(""+idMateria);
       existeCurso(idMateria);}
       catch(SQLException e){}
        if(!existe){
            JOptionPane.showMessageDialog(null, "No tiene un curso asignado");
        }else{
        n=3;
        confi.setVisible(true);
        if(!confi.eleccion()){
            asignarMateriaDesdeLabel(listaMaterias.get(2));
            crearCorreo(alumno);
            sendEmail();
            
            JOptionPane.showMessageDialog(null, "Materia asignada exitosamente | correo enviado");
        this.dispose();}
            existe = false;
        }
    }//GEN-LAST:event_panelMateria3MouseClicked

    private void panelMateria4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panelMateria4MouseClicked
        try{
        int idMateria = listaMaterias2.get(0).getId();
        System.out.println(""+idMateria);
      //  alumnoMat = alumnos.obtenerAlumnoPorIdMateria(idMateria);
        
       System.out.println(""+idMateria);
       existeCurso(idMateria);}
       catch(SQLException e){}
        if(!existe){
            JOptionPane.showMessageDialog(null, "No tiene un curso asignado");
        }else{
        n=4;
        confi.setVisible(true);
        if(!confi.eleccion()){
            asignarMateriaDesdeLabel(listaMaterias2.get(0));
            crearCorreo(alumno);
            sendEmail();
            
            JOptionPane.showMessageDialog(null, "Materia asignada exitosamente | correo enviado");
        this.dispose();
        }
            existe = false;
        }
    }//GEN-LAST:event_panelMateria4MouseClicked

    private void panelMateria5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panelMateria5MouseClicked
        try{
        int idMateria = listaMaterias2.get(1).getId();
        
     //   alumnoMat = alumnos.obtenerAlumnoPorIdMateria(idMateria);
        
       System.out.println(""+idMateria);
       existeCurso(idMateria);}
       catch(SQLException e){}
        if(!existe){
            JOptionPane.showMessageDialog(null, "No tiene un curso asignado");
        }else{
        n=5;
        confi.setVisible(true);
        if(!confi.eleccion()){
             asignarMateriaDesdeLabel(listaMaterias2.get(1));
            crearCorreo(alumno);
            sendEmail();
           
            JOptionPane.showMessageDialog(null, "Materia asignada exitosamente | correo enviado");
        this.dispose();}
            existe = false;
        }
    }//GEN-LAST:event_panelMateria5MouseClicked

    private void panelMateria6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panelMateria6MouseClicked
        try{
        int idMateria = listaMaterias2.get(2).getId();
        
   //     alumnoMat = alumnos.obtenerAlumnoPorIdMateria(idMateria);
        
       System.out.println(""+idMateria);
       existeCurso(idMateria);}
       catch(SQLException e){}
        if(!existe){
            JOptionPane.showMessageDialog(null, "No tiene un curso asignado");
        }else{
        n=6;
        confi.setVisible(true);
        if(!confi.eleccion()){
           asignarMateriaDesdeLabel(listaMaterias2.get(2));
            crearCorreo(alumno);
            sendEmail();
            
            JOptionPane.showMessageDialog(null, "Materia asignada exitosamente | correo enviado");
        this.dispose();
        }
            existe = false;
        }
    }//GEN-LAST:event_panelMateria6MouseClicked

    private void panelMateria7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panelMateria7MouseClicked
        try{
        int idMateria = listaMaterias3.get(0).getId();
        
     //   alumnoMat = alumnos.obtenerAlumnoPorIdMateria(idMateria);
        
       System.out.println(""+idMateria);
       existeCurso(idMateria);}
       catch(SQLException e){}
        if(!existe){
            JOptionPane.showMessageDialog(null, "No tiene un curso asignado");
        }else{
        n=7;
        confi.setVisible(true);
        if(!confi.eleccion()){
            asignarMateriaDesdeLabel(listaMaterias3.get(0));
            crearCorreo(alumno);
            sendEmail();
            
            JOptionPane.showMessageDialog(null, "Materia asignada exitosamente | correo enviado");
        this.dispose();}
            existe = false;
        }
    }//GEN-LAST:event_panelMateria7MouseClicked

    private void panelMateria8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panelMateria8MouseClicked
        try{
        int idMateria = listaMaterias3.get(1).getId();
        
   //     alumnoMat = alumnos.obtenerAlumnoPorIdMateria(idMateria);
        
       System.out.println(""+idMateria);
       existeCurso(idMateria);}
       catch(SQLException e){}
        if(!existe){
            JOptionPane.showMessageDialog(null, "No tiene un curso asignado");
        }else{
        n=8;
        confi.setVisible(true);
        if(!confi.eleccion()){
            asignarMateriaDesdeLabel(listaMaterias3.get(1));
            crearCorreo(alumno);
            sendEmail();
            
            JOptionPane.showMessageDialog(null, "Materia asignada exitosamente | correo enviado");
        this.dispose();}
            existe = false;
        }
    }//GEN-LAST:event_panelMateria8MouseClicked

    private void panelMateria9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panelMateria9MouseClicked
         try{
        int idMateria = listaMaterias3.get(2).getId();
        
   //     alumnoMat = alumnos.obtenerAlumnoPorIdMateria(idMateria);
        
       System.out.println(""+idMateria);
       existeCurso(idMateria);}
       catch(SQLException e){}
        if(!existe){
            JOptionPane.showMessageDialog(null, "No tiene un curso asignado");
        }else{
        n=9;
        confi.setVisible(true);
        if(!confi.eleccion()){
            asignarMateriaDesdeLabel(listaMaterias3.get(2));
            crearCorreo(alumno);
            sendEmail();
            
            JOptionPane.showMessageDialog(null, "Materia asignada exitosamente | correo enviado");
        this.dispose();}
            existe = false;
        }
    }//GEN-LAST:event_panelMateria9MouseClicked

    private boolean calculo(){
        return capacidad<=0 ;
    }
    
    public int getmateriaSeleccionada(){
        return n;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AsignarMaterias.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AsignarMaterias.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AsignarMaterias.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AsignarMaterias.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                AsignarMaterias dialog = new AsignarMaterias(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel lblMat1;
    private javax.swing.JLabel lblMat2;
    private javax.swing.JLabel lblMat3;
    private javax.swing.JLabel lblMat4;
    private javax.swing.JLabel lblMat5;
    private javax.swing.JLabel lblMat6;
    private javax.swing.JLabel lblMat7;
    private javax.swing.JLabel lblMat8;
    private javax.swing.JLabel lblMat9;
    private javax.swing.JLabel lblTitulo;
    private javax.swing.JLabel lblimgMat1;
    private javax.swing.JLabel lblimgMat2;
    private javax.swing.JLabel lblimgMat3;
    private javax.swing.JLabel lblimgMat4;
    private javax.swing.JLabel lblimgMat5;
    private javax.swing.JLabel lblimgMat6;
    private javax.swing.JLabel lblimgMat7;
    private javax.swing.JLabel lblimgMat8;
    private javax.swing.JLabel lblimgMat9;
    private javax.swing.JPanel panelFondo;
    private javax.swing.JPanel panelMateria1;
    private javax.swing.JPanel panelMateria2;
    private javax.swing.JPanel panelMateria3;
    private javax.swing.JPanel panelMateria4;
    private javax.swing.JPanel panelMateria5;
    private javax.swing.JPanel panelMateria6;
    private javax.swing.JPanel panelMateria7;
    private javax.swing.JPanel panelMateria8;
    private javax.swing.JPanel panelMateria9;
    private javax.swing.JPanel panelOpciones;
    private javax.swing.JPanel panelTItulo;
    // End of variables declaration//GEN-END:variables
}
