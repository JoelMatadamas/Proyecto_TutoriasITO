/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package paquetegrafico;

import Modelo.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author salin
 */
public class VentanaTutores extends javax.swing.JFrame {
         private JLabel lblmenuBarras;
         private ImageIcon menuba;
         private boolean configclick;
         private AgregarTutor agregar;
         private Usuario usuario;
         private Tutor tutor;
         private Tutor tutorSeleccionado;
         private AccesoTutores tutores;
    /**
     * Creates new form MenuPrincipal
     */
    public VentanaTutores() {
        initComponents();
        lblmenuBarras = new JLabel();
        tutor = new Tutor();
        tutores = new AccesoTutores();
        agregar = new AgregarTutor(null,true);
        menuba = new ImageIcon(getClass().getResource("menuBarrasfn.png"));
        lblmenuBarras.setIcon(menuba);
        lblmenuBarras.setBounds(5, 5, 25, 25);
        lblmenuBarras.setVisible(false);
        lblmenuBarras.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        panelMenu.setVisible(true);
        panelFondo.add(lblmenuBarras);
        configclick = true;
        
        btnActualizarTutor.setEnabled(false);
        btnEliminar.setEnabled(false);

         lblmenuBarras.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                menuBarrasMouseClicked(e);
            }
        });
         
         
           DefaultTableModel modelo = (DefaultTableModel) tablaDatos.getModel();
modelo.setColumnIdentifiers(new String[]{"RFC", "Nombre", "Apellido Paterno", "Apellido Materno", "NumTel", "Correo"});
tablaDatos.setModel(modelo);
tablaDatos.setDefaultEditor(Object.class, new DefaultCellEditor(new JTextField()));   

// Asignar editores personalizados
tablaDatos.getColumnModel().getColumn(0).setCellEditor(new NumericCellEditor()); // RFC
tablaDatos.getColumnModel().getColumn(1).setCellEditor(new LetterCellEditor()); // Nombre
tablaDatos.getColumnModel().getColumn(2).setCellEditor(new LetterCellEditor()); // Apellido Paterno
tablaDatos.getColumnModel().getColumn(3).setCellEditor(new LetterCellEditor()); // Apellido Materno
tablaDatos.getColumnModel().getColumn(4).setCellEditor(new NumericCellEditor()); // NumTel
tablaDatos.getColumnModel().getColumn(5).setCellEditor(new LetterCellEditor()); // Correo
    }
        public class NumericCellEditor extends DefaultCellEditor {

        public NumericCellEditor() {
            super(new JTextField());
            ((JTextField) getComponent()).addKeyListener(new KeyAdapter() {
                public void keyTyped(KeyEvent e) {
                    char c = e.getKeyChar();
                    if (!Character.isDigit(c)) {
                        e.consume(); // Ignorar el evento si no es un dígito
                    }
                }
            });
        }
    }

    public class LetterCellEditor extends DefaultCellEditor {

        public LetterCellEditor() {
            super(new JTextField());
            ((JTextField) getComponent()).addKeyListener(new KeyAdapter() {
                public void keyTyped(KeyEvent e) {
                    char c = e.getKeyChar();
                    if (!Character.isLetter(c) && c != KeyEvent.VK_SPACE) {
                        e.consume(); // Ignorar el evento si no es una letra o espacio
                    }
                }
            });
        }
         
         public class EmailCellEditor extends DefaultCellEditor {
    public EmailCellEditor() {
        super(new JTextField());
        ((JTextField) getComponent()).addKeyListener(new KeyAdapter() {
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                // Aquí podrías agregar lógica adicional para validar caracteres permitidos en un correo
                if (c == '@' || c == '.') {
                    return; // Permitir '@' y '.' para el correo
                }
                if (!Character.isLetterOrDigit(c) && c != KeyEvent.VK_SPACE) {
                    e.consume(); // Ignorar el evento si no es un carácter válido
                }
            }
        });
    }
}

         
    }
    
    public void asignarUsuario(Usuario usuario){
        this.usuario = usuario;
        lblUsuario.setText(usuario.getUsuario());
    }
    
    private void cargarDatos() {
         java.util.List<Tutor> listaTutores;
    try {
        listaTutores = tutores.getTutores();
        DefaultTableModel modelo = (DefaultTableModel) tablaDatos.getModel();
        modelo.setRowCount(0);
        
        for (Tutor alum : listaTutores) {
            Object[] fila = {
                alum.getRfc(), 
                alum.getNombre(), 
                alum.getAPaterno(), 
                alum.getAMaterno(), 
                alum.getNumTel(),
                alum.getCorreo()
            };
            modelo.addRow(fila);
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    }
    
    private void buscarTutor(){
        
        if(txtRFC.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "Ingresa un rfc");
        }
        else{
            int rfc = Integer.parseInt(txtRFC.getText());
            try {
            tutor = tutores.obtenerTutor(rfc);
                } catch (SQLException ex) {
            Logger.getLogger(Loggin.class.getName()).log(Level.SEVERE, null, ex);
        }
            
        if(tutor != null){
            DefaultTableModel modelo = (DefaultTableModel) tablaDatos.getModel();
        modelo.setRowCount(0);
        
        Object[] fila = {
            tutor.getRfc(), 
            tutor.getNombre(), 
            tutor.getAPaterno(), 
            tutor.getAMaterno(), 
            tutor.getNumTel(), 
            tutor.getCorreo()
        };
        modelo.addRow(fila);
    } else {
        JOptionPane.showMessageDialog(this, "RFC no encontrado");
        }
        }
    }

    private void obtenerTutorSeleccionado() {
        int seleccion = tablaDatos.getSelectedRow();
        if (seleccion != -1) {
            String correo=  (String) tablaDatos.getValueAt(seleccion, 5);
            try {
                tutorSeleccionado = tutores.getTutorconCorreo(correo);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        menuOpciones = new javax.swing.JPopupMenu();
        menuCrearAdmin = new javax.swing.JMenuItem();
        separador1 = new javax.swing.JPopupMenu.Separator();
        menuoptCerrar = new javax.swing.JMenuItem();
        panelFondo = new javax.swing.JPanel();
        panelMenu = new javax.swing.JPanel();
        lblHogar = new javax.swing.JLabel();
        lblAlumnos = new javax.swing.JLabel();
        lblMaterias = new javax.swing.JLabel();
        lblRetroceder = new javax.swing.JLabel();
        lblConfig = new javax.swing.JLabel();
        paneltitulo = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        lblImagenAdorno = new javax.swing.JLabel();
        lblUsuario = new javax.swing.JLabel();
        panelTutores = new javax.swing.JPanel();
        filler1 = new javax.swing.Box.Filler(new java.awt.Dimension(0, 0), new java.awt.Dimension(0, 0), new java.awt.Dimension(0, 0));
        panelBusqueda = new javax.swing.JPanel();
        lblnumControl = new javax.swing.JLabel();
        txtRFC = new javax.swing.JTextField();
        btnBuscar = new javax.swing.JButton();
        btnTutores = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JSeparator();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaDatos = new javax.swing.JTable();
        btnAgregar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        btnActualizarTutor = new javax.swing.JButton();

        menuCrearAdmin.setText("Crear nuevo administrador");
        menuCrearAdmin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuCrearAdminActionPerformed(evt);
            }
        });
        menuOpciones.add(menuCrearAdmin);
        menuOpciones.add(separador1);

        menuoptCerrar.setText("Cerrar Sesión");
        menuoptCerrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuoptCerrarActionPerformed(evt);
            }
        });
        menuOpciones.add(menuoptCerrar);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Menu Principal");
        setResizable(false);

        panelFondo.setBackground(new java.awt.Color(255, 255, 255));

        panelMenu.setBackground(new java.awt.Color(0, 0, 204));

        lblHogar.setForeground(new java.awt.Color(255, 255, 255));
        lblHogar.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblHogar.setText("Hogar");
        lblHogar.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        lblHogar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblHogarMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblHogarMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblHogarMouseExited(evt);
            }
        });

        lblAlumnos.setForeground(new java.awt.Color(255, 255, 255));
        lblAlumnos.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblAlumnos.setText("Alumnos");
        lblAlumnos.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        lblAlumnos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblAlumnosMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblAlumnosMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblAlumnosMouseExited(evt);
            }
        });

        lblMaterias.setForeground(new java.awt.Color(255, 255, 255));
        lblMaterias.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblMaterias.setText("Materias");
        lblMaterias.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        lblMaterias.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblMateriasMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblMateriasMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblMateriasMouseExited(evt);
            }
        });

        lblRetroceder.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/flecha.png"))); // NOI18N
        lblRetroceder.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblRetroceder.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblRetrocederMouseClicked(evt);
            }
        });

        lblConfig.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/configuracionb.png"))); // NOI18N
        lblConfig.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblConfig.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblConfigMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout panelMenuLayout = new javax.swing.GroupLayout(panelMenu);
        panelMenu.setLayout(panelMenuLayout);
        panelMenuLayout.setHorizontalGroup(
            panelMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelMenuLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblHogar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 88, Short.MAX_VALUE)
                    .addComponent(lblAlumnos, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblMaterias, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelMenuLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(lblRetroceder, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelMenuLayout.createSequentialGroup()
                        .addComponent(lblConfig, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        panelMenuLayout.setVerticalGroup(
            panelMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelMenuLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblRetroceder, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(39, 39, 39)
                .addComponent(lblHogar, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblAlumnos, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblMaterias, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 403, Short.MAX_VALUE)
                .addComponent(lblConfig, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        paneltitulo.setBackground(new java.awt.Color(204, 204, 204));

        jLabel1.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 24)); // NOI18N
        jLabel1.setText("Tutores");
        paneltitulo.add(jLabel1);

        lblImagenAdorno.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/userfn.png"))); // NOI18N

        lblUsuario.setFont(new java.awt.Font("Segoe UI Semibold", 1, 12)); // NOI18N
        lblUsuario.setText("Usuario");

        panelTutores.setBackground(new java.awt.Color(255, 255, 255));

        panelBusqueda.setBackground(new java.awt.Color(255, 255, 255));

        lblnumControl.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblnumControl.setText("RFC:");

        txtRFC.setBorder(null);
        txtRFC.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtRFCKeyTyped(evt);
            }
        });

        btnBuscar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnBuscar.setText("Buscar");
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });

        btnTutores.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnTutores.setText("Todos los tutores");
        btnTutores.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTutoresActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelBusquedaLayout = new javax.swing.GroupLayout(panelBusqueda);
        panelBusqueda.setLayout(panelBusquedaLayout);
        panelBusquedaLayout.setHorizontalGroup(
            panelBusquedaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelBusquedaLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblnumControl)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelBusquedaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jSeparator1)
                    .addComponent(txtRFC, javax.swing.GroupLayout.DEFAULT_SIZE, 165, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnBuscar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnTutores)
                .addGap(29, 29, 29))
        );
        panelBusquedaLayout.setVerticalGroup(
            panelBusquedaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelBusquedaLayout.createSequentialGroup()
                .addGap(11, 11, 11)
                .addGroup(panelBusquedaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblnumControl)
                    .addComponent(txtRFC, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnBuscar)
                    .addComponent(btnTutores))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24))
        );

        jScrollPane1.setBackground(new java.awt.Color(255, 255, 255));

        tablaDatos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "RFC", "Nombre", "Ap. Paterno", "Ap. Materno", "Numero tel.", "Correo"
            }
        ));
        tablaDatos.setRowHeight(30);
        tablaDatos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaDatosMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tablaDatos);

        btnAgregar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnAgregar.setText("Agregar Tutor");
        btnAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarActionPerformed(evt);
            }
        });

        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        btnActualizarTutor.setText("Actualizar");
        btnActualizarTutor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActualizarTutorActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelTutoresLayout = new javax.swing.GroupLayout(panelTutores);
        panelTutores.setLayout(panelTutoresLayout);
        panelTutoresLayout.setHorizontalGroup(
            panelTutoresLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelTutoresLayout.createSequentialGroup()
                .addGroup(panelTutoresLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 691, Short.MAX_VALUE)
                    .addComponent(panelBusqueda, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(filler1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .addGroup(panelTutoresLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnAgregar)
                .addGap(27, 27, 27)
                .addComponent(btnEliminar)
                .addGap(26, 26, 26)
                .addComponent(btnActualizarTutor)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        panelTutoresLayout.setVerticalGroup(
            panelTutoresLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelTutoresLayout.createSequentialGroup()
                .addComponent(panelBusqueda, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(panelTutoresLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelTutoresLayout.createSequentialGroup()
                        .addGap(89, 89, 89)
                        .addComponent(filler1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelTutoresLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 378, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(panelTutoresLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnAgregar)
                    .addGroup(panelTutoresLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnActualizarTutor)
                        .addComponent(btnEliminar)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout panelFondoLayout = new javax.swing.GroupLayout(panelFondo);
        panelFondo.setLayout(panelFondoLayout);
        panelFondoLayout.setHorizontalGroup(
            panelFondoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelFondoLayout.createSequentialGroup()
                .addComponent(panelMenu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(panelFondoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(paneltitulo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelFondoLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 613, Short.MAX_VALUE)
                        .addComponent(lblImagenAdorno, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblUsuario)
                        .addGap(25, 25, 25))
                    .addGroup(panelFondoLayout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(panelTutores, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        panelFondoLayout.setVerticalGroup(
            panelFondoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelMenu, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(panelFondoLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelFondoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblImagenAdorno, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblUsuario, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(paneltitulo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(panelTutores, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelFondo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelFondo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void lblRetrocederMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblRetrocederMouseClicked
        panelMenu.setVisible(false);
        lblmenuBarras.setVisible(true);
    }//GEN-LAST:event_lblRetrocederMouseClicked

    private void lblConfigMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblConfigMouseClicked
        if(configclick == true){
        menuOpciones.show(this, lblConfig.getX(), lblConfig.getY()-25);
        configclick=false;
        }else if(configclick == false){
            menuOpciones.setVisible(false);
            configclick = true;
        }
    }//GEN-LAST:event_lblConfigMouseClicked

    private void menuoptCerrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuoptCerrarActionPerformed
        Loggin lg = new Loggin();
        lg.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_menuoptCerrarActionPerformed

    private void lblHogarMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblHogarMouseEntered
       lblHogar.setFont(lblHogar.getFont().deriveFont(Font.BOLD));
    }//GEN-LAST:event_lblHogarMouseEntered

    private void lblHogarMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblHogarMouseExited
        lblHogar.setFont(lblHogar.getFont().deriveFont(Font.PLAIN));
    }//GEN-LAST:event_lblHogarMouseExited

    private void lblAlumnosMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblAlumnosMouseEntered
        lblAlumnos.setFont(lblAlumnos.getFont().deriveFont(Font.BOLD));
    }//GEN-LAST:event_lblAlumnosMouseEntered

    private void lblAlumnosMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblAlumnosMouseExited
        lblAlumnos.setFont(lblAlumnos.getFont().deriveFont(Font.PLAIN));
    }//GEN-LAST:event_lblAlumnosMouseExited

    private void lblMateriasMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblMateriasMouseEntered
        lblMaterias.setFont(lblMaterias.getFont().deriveFont(Font.BOLD));
    }//GEN-LAST:event_lblMateriasMouseEntered

    private void lblMateriasMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblMateriasMouseExited
        lblMaterias.setFont(lblMaterias.getFont().deriveFont(Font.PLAIN));
    }//GEN-LAST:event_lblMateriasMouseExited

    private void lblHogarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblHogarMouseClicked
         this.dispose();
        MenuPrincipalAdmin mp = new MenuPrincipalAdmin();
        mp.asignarUsuario(usuario);
        mp.setVisible(true);
       
    }//GEN-LAST:event_lblHogarMouseClicked

    private void lblAlumnosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblAlumnosMouseClicked
         this.dispose();
        VentanaAlumnos va = new VentanaAlumnos();
       va.setVisible(true);
       va.asignarUsuario(usuario);
    }//GEN-LAST:event_lblAlumnosMouseClicked

    private void btnTutoresActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTutoresActionPerformed
       cargarDatos();
    }//GEN-LAST:event_btnTutoresActionPerformed

    private void lblMateriasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblMateriasMouseClicked
        this.dispose();
        VentanaMaterias vm =new VentanaMaterias();
        vm.asignarUsuario(usuario);
        vm.setVisible(true);
    }//GEN-LAST:event_lblMateriasMouseClicked

    private void btnAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarActionPerformed
        agregar.setVisible(true);
    }//GEN-LAST:event_btnAgregarActionPerformed

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
        buscarTutor();
    }//GEN-LAST:event_btnBuscarActionPerformed

    private void txtRFCKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtRFCKeyTyped
         char c = evt.getKeyChar();
        if(!Character.isDigit(c) ){
            evt.consume();
        }
    }//GEN-LAST:event_txtRFCKeyTyped

    private void menuCrearAdminActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuCrearAdminActionPerformed
        AgregarAdmin ad = new AgregarAdmin(null,true);
       ad.setVisible(true);
    }//GEN-LAST:event_menuCrearAdminActionPerformed

    private void tablaDatosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaDatosMouseClicked
       obtenerTutorSeleccionado();
        btnAgregar.setEnabled(true);
        btnActualizarTutor.setEnabled(true);
        btnEliminar.setEnabled(true);
    }//GEN-LAST:event_tablaDatosMouseClicked

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
       obtenerTutorSeleccionado();
        if (tutorSeleccionado != null) {
            int confirm = JOptionPane.showConfirmDialog(this, "¿Está seguro de que desea eliminar el tutor seleccionado?", "Confirmar eliminación", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                try {
                    System.out.println(""+tutorSeleccionado.getId());
                    if (tutores.eliminarTutor(tutorSeleccionado.getId())) {
                        JOptionPane.showMessageDialog(this, "Tutor eliminado correctamente.");
                        cargarDatos();
                    } else {
                        JOptionPane.showMessageDialog(this, "Error al eliminar el Tutor.");
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                    JOptionPane.showMessageDialog(this, "Error al eliminar el Tutor: " + e.getMessage());
                }
            }
        }
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnActualizarTutorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarTutorActionPerformed
       obtenerTutorSeleccionado();
if (tutorSeleccionado != null) {
    int seleccion = tablaDatos.getSelectedRow();
    if (seleccion != -1) {
        tutorSeleccionado.setNombre((String) tablaDatos.getValueAt(seleccion, 1));
        tutorSeleccionado.setAPaterno((String) tablaDatos.getValueAt(seleccion, 2));
        tutorSeleccionado.setAMaterno((String) tablaDatos.getValueAt(seleccion, 3));

        // Convertir el valor del número telefónico a String
        String numTel = (String) tablaDatos.getValueAt(seleccion, 4);
        tutorSeleccionado.setNumTel(numTel);

        tutorSeleccionado.setCorreo((String) tablaDatos.getValueAt(seleccion, 5));
        
        try {
            tutores.actualizarTutor(tutorSeleccionado);
            if (tutores.actualizarTutor(tutorSeleccionado)) {
                JOptionPane.showMessageDialog(this, "Tutor actualizado correctamente.");
                tablaDatos.clearSelection();
                cargarDatos(); // Asumiendo que este método recarga los datos en la tabla
            } else {
                JOptionPane.showMessageDialog(this, "Error al actualizar el tutor.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al actualizar el tutor: " + e.getMessage());
        }
    }
}

       
    }//GEN-LAST:event_btnActualizarTutorActionPerformed

    private void menuBarrasMouseClicked(MouseEvent e) {
        lblmenuBarras.setVisible(false);
        panelMenu.setVisible(true);
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VentanaTutores.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VentanaTutores.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VentanaTutores.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VentanaTutores.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VentanaTutores().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnActualizarTutor;
    private javax.swing.JButton btnAgregar;
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnTutores;
    private javax.swing.Box.Filler filler1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JLabel lblAlumnos;
    private javax.swing.JLabel lblConfig;
    private javax.swing.JLabel lblHogar;
    private javax.swing.JLabel lblImagenAdorno;
    private javax.swing.JLabel lblMaterias;
    private javax.swing.JLabel lblRetroceder;
    private javax.swing.JLabel lblUsuario;
    private javax.swing.JLabel lblnumControl;
    private javax.swing.JMenuItem menuCrearAdmin;
    private javax.swing.JPopupMenu menuOpciones;
    private javax.swing.JMenuItem menuoptCerrar;
    private javax.swing.JPanel panelBusqueda;
    private javax.swing.JPanel panelFondo;
    private javax.swing.JPanel panelMenu;
    private javax.swing.JPanel panelTutores;
    private javax.swing.JPanel paneltitulo;
    private javax.swing.JPopupMenu.Separator separador1;
    private javax.swing.JTable tablaDatos;
    private javax.swing.JTextField txtRFC;
    // End of variables declaration//GEN-END:variables
}
