/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package paquetegrafico;

import Modelo.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.SQLException;
import java.util.List;

/**
 *
 * @author salin
 */
public class VentanaMisClasesTutores extends javax.swing.JFrame {
         private JLabel lblmenuBarras;
         private ImageIcon menuba;
         private boolean configclick;
         public Usuario usuario;
         public Tutor tutor;
         private AccesoTutores tutores;
         private AccesoCursos cursos;
         public Curso curso;
         private Materia materia;
         private AccesoMaterias materias;
         MenuPrincipalTutor mp;
         private String hola;
         private Lista lista;
    /**
     * Creates new form MenuPrincipal
     */
    public VentanaMisClasesTutores() {
        initComponents();
        lista = new Lista(null,true);
        materias = new AccesoMaterias();
        materia = new Materia();
         mp = new MenuPrincipalTutor();
        //tutor = new Tutor();
        tutores = new AccesoTutores();
        cursos = new AccesoCursos();
        curso = new Curso();
        //usuario = new Usuario();
        lblmenuBarras = new JLabel();
        menuba = new ImageIcon(getClass().getResource("menuBarrasfn.png"));
        lblmenuBarras.setIcon(menuba);
        lblmenuBarras.setBounds(5, 5, 25, 25);
        lblmenuBarras.setVisible(false);
        lblmenuBarras.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        panelMenu.setVisible(true);
        panelFondo.add(lblmenuBarras);
        configclick = true;
        panelMateria1.setVisible(false);
        panelMateria2.setVisible(false);
        panelMateria3.setVisible(false);

         lblmenuBarras.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                menuBarrasMouseClicked(e);
            }
        });
         
         
         //mostrarMaterias();
         
    }
    
   

     public void asignarUsuario(Usuario usuario){
        this.usuario = usuario;
        hola = usuario.getCorreo();
        lblUsuario.setText(usuario.getUsuario());
    }
     
    public void asignarTutor(Tutor tutor, int id) {
    this.tutor = tutor;
    try {
        this.tutor = tutores.obtenerTutorconID(id);
    } catch (SQLException e) {
        e.printStackTrace();
    }

    System.out.println("prueba 1: " + tutor.getNombre());
    System.out.println("prueba 2: " + tutor.getId());

    if (tutor != null) {
        try {
            List<Curso> cursosTutor = cursos.getCursosPorTutor(tutor.getId()); // Obtener todos los cursos del tutor
            
            // Limpiar paneles
            panelMateria1.setVisible(false);
            panelMateria2.setVisible(false);
            panelMateria3.setVisible(false);
            
            // Mostrar materias en los paneles correspondientes
            if (cursosTutor.size() > 0) {
                for (int i = 0; i < cursosTutor.size() && i < 3; i++) {
                    Curso cursoActual = cursosTutor.get(i);
                    materia = materias.obtenerMateria(cursoActual.getIdMateria());

                    // Actualizar los paneles con la información de la materia
                    switch (i) {
                        case 0:
                            lblNombreMat1.setText(materia.getNombre());
                            lblAulaMat1.setText(cursoActual.getAula());
                            lblHoraInicioMat1.setText(String.valueOf(cursoActual.getHoraInicio()));
                            lblHoraFinMat1.setText(String.valueOf(cursoActual.getHoraFin()));
                            lblTotalAlumnosMat1.setText(String.valueOf(materia.getCapacidad()));
                            panelMateria1.setVisible(true);
                            break;
                        case 1:
                            lblNombreMat2.setText(materia.getNombre());
                            lblAulaMat2.setText(cursoActual.getAula());
                            lblHoraInicioMat2.setText(String.valueOf(cursoActual.getHoraInicio()));
                            lblHoraFinMat2.setText(String.valueOf(cursoActual.getHoraFin()));
                            lblTotalAlumnosMat2.setText(String.valueOf(materia.getCapacidad()));
                            panelMateria2.setVisible(true);
                            break;
                        case 2:
                            lblNombreMat3.setText(materia.getNombre());
                            lblAulaMat3.setText(cursoActual.getAula());
                            lblHoraInicioMat3.setText(String.valueOf(cursoActual.getHoraInicio()));
                            lblHoraFinMat3.setText(String.valueOf(cursoActual.getHoraFin()));
                            lblTotalAlumnosMat3.setText(String.valueOf(materia.getCapacidad()));
                            panelMateria3.setVisible(true);
                            break;
                    }
                }
            } else {
                // Si no hay cursos asignados, mostrar "Sin asignar"
                mostrarSinAsignar(panelMateria1, lblNombreMat1, lblAulaMat1, lblHoraInicioMat1, lblHoraFinMat1, lblTotalAlumnosMat1);
                mostrarSinAsignar(panelMateria2, lblNombreMat2, lblAulaMat2, lblHoraInicioMat2, lblHoraFinMat2, lblTotalAlumnosMat2);
                mostrarSinAsignar(panelMateria3, lblNombreMat3, lblAulaMat3, lblHoraInicioMat3, lblHoraFinMat3, lblTotalAlumnosMat3);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al cargar las materias: " + e.getMessage());
        }
    } else {
        // Si no hay tutor asignado
        mostrarSinAsignar(panelMateria1, lblNombreMat1, lblAulaMat1, lblHoraInicioMat1, lblHoraFinMat1, lblTotalAlumnosMat1);
        mostrarSinAsignar(panelMateria2, lblNombreMat2, lblAulaMat2, lblHoraInicioMat2, lblHoraFinMat2, lblTotalAlumnosMat2);
        mostrarSinAsignar(panelMateria3, lblNombreMat3, lblAulaMat3, lblHoraInicioMat3, lblHoraFinMat3, lblTotalAlumnosMat3);
    }
}

private void mostrarSinAsignar(JPanel panel, JLabel lblNombre, JLabel lblAula, JLabel lblHoraInicio, JLabel lblHoraFin, JLabel lblTotalAlumnos) {
    lblNombre.setText("Sin asignar");
    lblAula.setText("Sin asignar");
    lblHoraInicio.setText("Sin asignar");
    lblHoraFin.setText("Sin asignar");
    lblTotalAlumnos.setText("Sin asignar");
    panel.setVisible(true); // Asegúrate de que el panel se muestre
}

     
     
     /*
      public void obtenerTutor(){
        System.out.println("prueba usuario mis clases "+usuario.getCorreo());
        System.out.println("prueba tutor mis clases "+tutor.getAPaterno());
        
    }*/
    
   public Curso obtenerCursoDelPanel(int panelNumero) throws SQLException {
        List<Curso> cursosTutor = cursos.getCursosPorTutor(tutor.getId());
        if (panelNumero > 0 && panelNumero <= cursosTutor.size()) {
            return cursosTutor.get(panelNumero - 1);
        } else {
            throw new IllegalArgumentException("Panel número fuera de rango");
        }
    }
      
      public Curso obtenerCurso() throws SQLException {
        //if (usuario != null) {
            int correoTutor = tutor.getId();
            System.out.println("id del tutor en obtenerCurso: " + correoTutor);
            curso = cursos.obtenerCursoPorTutor(tutor.getId());
            System.out.println("id del curso obtenerCurso() "+curso.getIdCurso());
            return curso;
       // } else {
         //  throw new IllegalStateException("Usuario no asignado");
       // }
    }
     
       public Tutor obtenerTutor() throws SQLException {
        //if (usuario != null) {
            String correoTutor = usuario.getCorreo();
            System.out.println("Correo del tutor en obtenerTutor: " + correoTutor);
            tutor = tutores.getTutorconCorreo(correoTutor);
            System.out.println("nombre del tutor obtenerTutor() "+tutor.getNombre());
            return tutor;
       // } else {
         //  throw new IllegalStateException("Usuario no asignado");
       // }
    }
      
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        menuOpciones = new javax.swing.JPopupMenu();
        separador1 = new javax.swing.JPopupMenu.Separator();
        menuoptCerrar = new javax.swing.JMenuItem();
        panelFondo = new javax.swing.JPanel();
        panelMenu = new javax.swing.JPanel();
        lblHogar = new javax.swing.JLabel();
        lblTutores = new javax.swing.JLabel();
        lblAlumnos = new javax.swing.JLabel();
        lblRetroceder = new javax.swing.JLabel();
        lblConfig = new javax.swing.JLabel();
        paneltitulo = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        lblImagenAdorno = new javax.swing.JLabel();
        lblUsuario = new javax.swing.JLabel();
        panelAlumnos = new javax.swing.JPanel();
        panelMateria1 = new javax.swing.JPanel();
        lblImagenMat3 = new javax.swing.JLabel();
        lblNombreMat1 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        lblHoraInicioMat1 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        lblHoraFinMat1 = new javax.swing.JLabel();
        lblAulaMat1 = new javax.swing.JLabel();
        lblTotalAlumnosMat1 = new javax.swing.JLabel();
        btnMOstrarListaMat1 = new javax.swing.JButton();
        panelMateria2 = new javax.swing.JPanel();
        lblImagenMat2 = new javax.swing.JLabel();
        lblNombreMat2 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        lblHoraInicioMat2 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        lblHoraFinMat2 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        lblAulaMat2 = new javax.swing.JLabel();
        btnMOstrarListaMat2 = new javax.swing.JButton();
        jLabel12 = new javax.swing.JLabel();
        lblTotalAlumnosMat2 = new javax.swing.JLabel();
        panelMateria3 = new javax.swing.JPanel();
        lblImagenMat1 = new javax.swing.JLabel();
        lblNombreMat3 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        lblHoraInicioMat3 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        lblHoraFinMat3 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        lblAulaMat3 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        lblTotalAlumnosMat3 = new javax.swing.JLabel();
        btnMOstrarListaMat3 = new javax.swing.JButton();

        menuOpciones.add(separador1);

        menuoptCerrar.setText("Cerrar Sesión");
        menuoptCerrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuoptCerrarActionPerformed(evt);
            }
        });
        menuOpciones.add(menuoptCerrar);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Menu Principal");
        setResizable(false);

        panelFondo.setBackground(new java.awt.Color(255, 255, 255));

        panelMenu.setBackground(new java.awt.Color(0, 0, 204));

        lblHogar.setForeground(new java.awt.Color(255, 255, 255));
        lblHogar.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblHogar.setText("Hogar");
        lblHogar.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        lblHogar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblHogarMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblHogarMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblHogarMouseExited(evt);
            }
        });

        lblTutores.setForeground(new java.awt.Color(255, 255, 255));
        lblTutores.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTutores.setText("Recursos");
        lblTutores.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        lblTutores.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblTutoresMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblTutoresMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblTutoresMouseExited(evt);
            }
        });

        lblAlumnos.setForeground(new java.awt.Color(255, 255, 255));
        lblAlumnos.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblAlumnos.setText("Alumnos");
        lblAlumnos.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        lblAlumnos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblAlumnosMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblAlumnosMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblAlumnosMouseExited(evt);
            }
        });

        lblRetroceder.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/flecha.png"))); // NOI18N
        lblRetroceder.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblRetroceder.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblRetrocederMouseClicked(evt);
            }
        });

        lblConfig.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/configuracionb.png"))); // NOI18N
        lblConfig.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblConfig.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblConfigMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout panelMenuLayout = new javax.swing.GroupLayout(panelMenu);
        panelMenu.setLayout(panelMenuLayout);
        panelMenuLayout.setHorizontalGroup(
            panelMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelMenuLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblHogar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 88, Short.MAX_VALUE)
                    .addComponent(lblTutores, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblAlumnos, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelMenuLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(lblRetroceder, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelMenuLayout.createSequentialGroup()
                        .addComponent(lblConfig, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        panelMenuLayout.setVerticalGroup(
            panelMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelMenuLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblRetroceder, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(39, 39, 39)
                .addComponent(lblHogar, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblTutores, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblAlumnos, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 403, Short.MAX_VALUE)
                .addComponent(lblConfig, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        paneltitulo.setBackground(new java.awt.Color(204, 204, 204));

        jLabel1.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 24)); // NOI18N
        jLabel1.setText("Mis Clases");
        paneltitulo.add(jLabel1);

        lblImagenAdorno.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/userfn.png"))); // NOI18N

        lblUsuario.setFont(new java.awt.Font("Segoe UI Semibold", 1, 12)); // NOI18N
        lblUsuario.setText("Usuario");

        panelAlumnos.setBackground(new java.awt.Color(255, 255, 255));
        panelAlumnos.setLayout(new java.awt.GridLayout(3, 0));

        panelMateria1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));

        lblImagenMat3.setBackground(new java.awt.Color(255, 255, 255));
        lblImagenMat3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblImagenMat3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/topicos.png"))); // NOI18N
        lblImagenMat3.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        lblImagenMat3.setOpaque(true);

        lblNombreMat1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblNombreMat1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblNombreMat1.setText("Nombre");

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel5.setText("Horario:");

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel6.setText("Aula:");

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel7.setText("Cantidad de Alumnos:");

        lblHoraInicioMat1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblHoraInicioMat1.setText("-");

        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel10.setText("-");

        lblHoraFinMat1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblHoraFinMat1.setText("-");

        lblAulaMat1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblAulaMat1.setText("-");

        lblTotalAlumnosMat1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTotalAlumnosMat1.setText("-");

        btnMOstrarListaMat1.setText("Mostrar Lista");
        btnMOstrarListaMat1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMOstrarListaMat1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelMateria1Layout = new javax.swing.GroupLayout(panelMateria1);
        panelMateria1.setLayout(panelMateria1Layout);
        panelMateria1Layout.setHorizontalGroup(
            panelMateria1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelMateria1Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(lblImagenMat3, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(panelMateria1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelMateria1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblNombreMat1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())
                    .addGroup(panelMateria1Layout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addGroup(panelMateria1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(panelMateria1Layout.createSequentialGroup()
                                .addGroup(panelMateria1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(jLabel6, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(panelMateria1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(panelMateria1Layout.createSequentialGroup()
                                        .addComponent(lblHoraInicioMat1, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(lblHoraFinMat1, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(lblAulaMat1, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(0, 93, Short.MAX_VALUE)
                                .addComponent(btnMOstrarListaMat1)
                                .addGap(33, 33, 33))
                            .addGroup(panelMateria1Layout.createSequentialGroup()
                                .addComponent(jLabel7)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lblTotalAlumnosMat1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))))
        );
        panelMateria1Layout.setVerticalGroup(
            panelMateria1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelMateria1Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addGroup(panelMateria1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelMateria1Layout.createSequentialGroup()
                        .addGroup(panelMateria1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(panelMateria1Layout.createSequentialGroup()
                                .addComponent(lblNombreMat1)
                                .addGap(18, 18, 18)
                                .addGroup(panelMateria1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel5)
                                    .addComponent(lblHoraInicioMat1)
                                    .addComponent(jLabel10)
                                    .addComponent(lblHoraFinMat1))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(panelMateria1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel6)
                                    .addComponent(lblAulaMat1)))
                            .addGroup(panelMateria1Layout.createSequentialGroup()
                                .addGap(48, 48, 48)
                                .addComponent(btnMOstrarListaMat1)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(panelMateria1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel7)
                            .addComponent(lblTotalAlumnosMat1)))
                    .addComponent(lblImagenMat3, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(26, Short.MAX_VALUE))
        );

        panelAlumnos.add(panelMateria1);

        panelMateria2.setBackground(new java.awt.Color(255, 255, 255));
        panelMateria2.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));

        lblImagenMat2.setBackground(new java.awt.Color(255, 255, 255));
        lblImagenMat2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblImagenMat2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/fisica.png"))); // NOI18N
        lblImagenMat2.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        lblImagenMat2.setOpaque(true);

        lblNombreMat2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblNombreMat2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblNombreMat2.setText("Nombre");

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel8.setText("Horario:");

        lblHoraInicioMat2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblHoraInicioMat2.setText("-");

        jLabel11.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel11.setText("-");

        lblHoraFinMat2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblHoraFinMat2.setText("-");

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel9.setText("Aula:");

        lblAulaMat2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblAulaMat2.setText("-");

        btnMOstrarListaMat2.setText("Mostrar Lista");
        btnMOstrarListaMat2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMOstrarListaMat2ActionPerformed(evt);
            }
        });

        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel12.setText("Cantidad de Alumnos:");

        lblTotalAlumnosMat2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTotalAlumnosMat2.setText("-");

        javax.swing.GroupLayout panelMateria2Layout = new javax.swing.GroupLayout(panelMateria2);
        panelMateria2.setLayout(panelMateria2Layout);
        panelMateria2Layout.setHorizontalGroup(
            panelMateria2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelMateria2Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(lblImagenMat2, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelMateria2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelMateria2Layout.createSequentialGroup()
                        .addComponent(lblNombreMat2, javax.swing.GroupLayout.DEFAULT_SIZE, 448, Short.MAX_VALUE)
                        .addContainerGap())
                    .addGroup(panelMateria2Layout.createSequentialGroup()
                        .addGap(36, 36, 36)
                        .addGroup(panelMateria2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(panelMateria2Layout.createSequentialGroup()
                                .addComponent(jLabel12)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lblTotalAlumnosMat2, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap())
                            .addGroup(panelMateria2Layout.createSequentialGroup()
                                .addGroup(panelMateria2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel8))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(panelMateria2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(panelMateria2Layout.createSequentialGroup()
                                        .addComponent(lblHoraInicioMat2, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(lblHoraFinMat2, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                    .addGroup(panelMateria2Layout.createSequentialGroup()
                                        .addComponent(lblAulaMat2, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(btnMOstrarListaMat2)
                                        .addGap(33, 33, 33))))))))
        );
        panelMateria2Layout.setVerticalGroup(
            panelMateria2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelMateria2Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(panelMateria2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelMateria2Layout.createSequentialGroup()
                        .addComponent(lblNombreMat2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(panelMateria2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8)
                            .addComponent(lblHoraInicioMat2)
                            .addComponent(jLabel11)
                            .addComponent(lblHoraFinMat2))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(panelMateria2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel9)
                            .addComponent(lblAulaMat2)
                            .addComponent(btnMOstrarListaMat2))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(panelMateria2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel12)
                            .addComponent(lblTotalAlumnosMat2)))
                    .addComponent(lblImagenMat2, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(29, Short.MAX_VALUE))
        );

        panelAlumnos.add(panelMateria2);

        panelMateria3.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));

        lblImagenMat1.setBackground(new java.awt.Color(255, 255, 255));
        lblImagenMat1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblImagenMat1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/bda.png"))); // NOI18N
        lblImagenMat1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        lblImagenMat1.setOpaque(true);

        lblNombreMat3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblNombreMat3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblNombreMat3.setText("Nombre");

        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel13.setText("Horario:");

        lblHoraInicioMat3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblHoraInicioMat3.setText("-");

        jLabel14.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel14.setText("-");

        lblHoraFinMat3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblHoraFinMat3.setText("-");

        jLabel15.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel15.setText("Aula:");

        lblAulaMat3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblAulaMat3.setText("-");

        jLabel16.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel16.setText("Cantidad de Alumnos:");

        lblTotalAlumnosMat3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTotalAlumnosMat3.setText("-");

        btnMOstrarListaMat3.setText("Mostrar Lista");
        btnMOstrarListaMat3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMOstrarListaMat3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelMateria3Layout = new javax.swing.GroupLayout(panelMateria3);
        panelMateria3.setLayout(panelMateria3Layout);
        panelMateria3Layout.setHorizontalGroup(
            panelMateria3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelMateria3Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(lblImagenMat1, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelMateria3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelMateria3Layout.createSequentialGroup()
                        .addComponent(lblNombreMat3, javax.swing.GroupLayout.DEFAULT_SIZE, 448, Short.MAX_VALUE)
                        .addGap(4, 4, 4))
                    .addGroup(panelMateria3Layout.createSequentialGroup()
                        .addGap(35, 35, 35)
                        .addComponent(jLabel13)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(lblHoraInicioMat3, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblHoraFinMat3, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnMOstrarListaMat3)
                        .addGap(30, 30, 30))
                    .addGroup(panelMateria3Layout.createSequentialGroup()
                        .addGap(36, 36, 36)
                        .addGroup(panelMateria3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(panelMateria3Layout.createSequentialGroup()
                                .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(lblAulaMat3, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(panelMateria3Layout.createSequentialGroup()
                                .addComponent(jLabel16)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lblTotalAlumnosMat3, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        panelMateria3Layout.setVerticalGroup(
            panelMateria3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelMateria3Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(panelMateria3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelMateria3Layout.createSequentialGroup()
                        .addComponent(lblNombreMat3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(panelMateria3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel13)
                            .addComponent(lblHoraInicioMat3)
                            .addComponent(jLabel14)
                            .addComponent(lblHoraFinMat3))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(panelMateria3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel15)
                            .addComponent(lblAulaMat3)
                            .addComponent(btnMOstrarListaMat3))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(panelMateria3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel16)
                            .addComponent(lblTotalAlumnosMat3)))
                    .addComponent(lblImagenMat1, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(27, Short.MAX_VALUE))
        );

        panelAlumnos.add(panelMateria3);

        javax.swing.GroupLayout panelFondoLayout = new javax.swing.GroupLayout(panelFondo);
        panelFondo.setLayout(panelFondoLayout);
        panelFondoLayout.setHorizontalGroup(
            panelFondoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelFondoLayout.createSequentialGroup()
                .addComponent(panelMenu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(panelFondoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(paneltitulo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelFondoLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblImagenAdorno, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblUsuario)
                        .addGap(25, 25, 25))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelFondoLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(panelAlumnos, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())))
        );
        panelFondoLayout.setVerticalGroup(
            panelFondoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelMenu, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(panelFondoLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelFondoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblImagenAdorno, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblUsuario, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(paneltitulo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(panelAlumnos, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelFondo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelFondo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void lblRetrocederMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblRetrocederMouseClicked
        panelMenu.setVisible(false);
        lblmenuBarras.setVisible(true);
    }//GEN-LAST:event_lblRetrocederMouseClicked

    private void lblConfigMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblConfigMouseClicked
        if(configclick == true){
        menuOpciones.show(this, lblConfig.getX(), lblConfig.getY()-25);
        configclick=false;
        }else if(configclick == false){
            menuOpciones.setVisible(false);
            configclick = true;
        }
    }//GEN-LAST:event_lblConfigMouseClicked

    private void menuoptCerrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuoptCerrarActionPerformed
        Loggin lg = new Loggin();
        lg.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_menuoptCerrarActionPerformed

    private void lblHogarMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblHogarMouseEntered
       lblHogar.setFont(lblHogar.getFont().deriveFont(Font.BOLD));
    }//GEN-LAST:event_lblHogarMouseEntered

    private void lblHogarMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblHogarMouseExited
        lblHogar.setFont(lblHogar.getFont().deriveFont(Font.PLAIN));
    }//GEN-LAST:event_lblHogarMouseExited

    private void lblTutoresMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblTutoresMouseEntered
        lblTutores.setFont(lblTutores.getFont().deriveFont(Font.BOLD));
    }//GEN-LAST:event_lblTutoresMouseEntered

    private void lblTutoresMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblTutoresMouseExited
        lblTutores.setFont(lblTutores.getFont().deriveFont(Font.PLAIN));
    }//GEN-LAST:event_lblTutoresMouseExited

    private void lblAlumnosMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblAlumnosMouseEntered
        lblAlumnos.setFont(lblAlumnos.getFont().deriveFont(Font.BOLD));
    }//GEN-LAST:event_lblAlumnosMouseEntered

    private void lblAlumnosMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblAlumnosMouseExited
        lblAlumnos.setFont(lblAlumnos.getFont().deriveFont(Font.PLAIN));
    }//GEN-LAST:event_lblAlumnosMouseExited

    private void lblHogarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblHogarMouseClicked
         this.dispose();
        mp.asignarUsuario(usuario);
        mp.setVisible(true);
       
    }//GEN-LAST:event_lblHogarMouseClicked

    private void lblTutoresMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblTutoresMouseClicked
         this.dispose();
        VentanaRecursos va = new VentanaRecursos();
        va.asignarUsuario(usuario);
       va.setVisible(true);
    }//GEN-LAST:event_lblTutoresMouseClicked

    private void lblAlumnosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblAlumnosMouseClicked
        try{              
        this.dispose();
        VentanaAlumnosTutor vm =new VentanaAlumnosTutor();
        vm.asignarTutor(obtenerTutor(), obtenerTutor().getId());
        vm.asignarUsuario(usuario);
        vm.setVisible(true);}
        catch(SQLException e){}
    }//GEN-LAST:event_lblAlumnosMouseClicked

    private void btnMOstrarListaMat1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMOstrarListaMat1ActionPerformed
        try{
            lista.obtenerCurso(obtenerCursoDelPanel(1));
            if(lista.hayAlumnos()){
        lista.setVisible(true);
            }else{JOptionPane.showMessageDialog(null,"No hay alumnos inscritos");}
        }catch(SQLException e){}
    }//GEN-LAST:event_btnMOstrarListaMat1ActionPerformed

    private void btnMOstrarListaMat2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMOstrarListaMat2ActionPerformed
        try{
            lista.obtenerCurso(obtenerCursoDelPanel(2));
        if(lista.hayAlumnos()){
        lista.setVisible(true);
            }else{JOptionPane.showMessageDialog(null,"No hay alumnos inscritos");}
        }catch(SQLException e){}
    }//GEN-LAST:event_btnMOstrarListaMat2ActionPerformed

    private void btnMOstrarListaMat3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMOstrarListaMat3ActionPerformed
        try{
            lista.obtenerCurso(obtenerCursoDelPanel(3));
        if(lista.hayAlumnos()){
        lista.setVisible(true);
            }else{JOptionPane.showMessageDialog(null,"No hay alumnos inscritos");}
        }catch(SQLException e){}
    }//GEN-LAST:event_btnMOstrarListaMat3ActionPerformed

    private void menuBarrasMouseClicked(MouseEvent e) {
        lblmenuBarras.setVisible(false);
        panelMenu.setVisible(true);
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VentanaMisClasesTutores.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VentanaMisClasesTutores.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VentanaMisClasesTutores.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VentanaMisClasesTutores.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VentanaMisClasesTutores().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnMOstrarListaMat1;
    private javax.swing.JButton btnMOstrarListaMat2;
    private javax.swing.JButton btnMOstrarListaMat3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel lblAlumnos;
    private javax.swing.JLabel lblAulaMat1;
    private javax.swing.JLabel lblAulaMat2;
    private javax.swing.JLabel lblAulaMat3;
    private javax.swing.JLabel lblConfig;
    private javax.swing.JLabel lblHogar;
    private javax.swing.JLabel lblHoraFinMat1;
    private javax.swing.JLabel lblHoraFinMat2;
    private javax.swing.JLabel lblHoraFinMat3;
    private javax.swing.JLabel lblHoraInicioMat1;
    private javax.swing.JLabel lblHoraInicioMat2;
    private javax.swing.JLabel lblHoraInicioMat3;
    private javax.swing.JLabel lblImagenAdorno;
    private javax.swing.JLabel lblImagenMat1;
    private javax.swing.JLabel lblImagenMat2;
    private javax.swing.JLabel lblImagenMat3;
    private javax.swing.JLabel lblNombreMat1;
    private javax.swing.JLabel lblNombreMat2;
    private javax.swing.JLabel lblNombreMat3;
    private javax.swing.JLabel lblRetroceder;
    private javax.swing.JLabel lblTotalAlumnosMat1;
    private javax.swing.JLabel lblTotalAlumnosMat2;
    private javax.swing.JLabel lblTotalAlumnosMat3;
    private javax.swing.JLabel lblTutores;
    private javax.swing.JLabel lblUsuario;
    private javax.swing.JPopupMenu menuOpciones;
    private javax.swing.JMenuItem menuoptCerrar;
    private javax.swing.JPanel panelAlumnos;
    private javax.swing.JPanel panelFondo;
    private javax.swing.JPanel panelMateria1;
    private javax.swing.JPanel panelMateria2;
    private javax.swing.JPanel panelMateria3;
    private javax.swing.JPanel panelMenu;
    private javax.swing.JPanel paneltitulo;
    private javax.swing.JPopupMenu.Separator separador1;
    // End of variables declaration//GEN-END:variables
}
