/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package paquetegrafico;

import Modelo.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author salin
 */
public class VentanaAlumnosTutor extends javax.swing.JFrame {
         private JLabel lblmenuBarras;
         private ImageIcon menuba;
         private boolean configclick;
         private CrearCurso Asignar;
         private Usuario usuario;
         public Tutor tutor;
         private AccesoTutores tutores;
         private AccesoCursos cursos;
         public Curso curso;
         private Materia materia;
         private AccesoMaterias materias;
         private java.util.List<Materia> listaMaterias;
         public Alumno alumno;
        public AccesoAlumnos alumnos;
        private java.util.List<Alumno> listaAlumnos;
    /**
     * Creates new form MenuPrincipal
     */
    public VentanaAlumnosTutor() {
        initComponents();
        listaAlumnos = new ArrayList<>();
        listaMaterias = new ArrayList<>();
        alumno = new Alumno();
        alumnos = new AccesoAlumnos();
        materias = new AccesoMaterias();
        materia = new Materia();
        //tutor = new Tutor();
        tutores = new AccesoTutores();
        cursos = new AccesoCursos();
        curso = new Curso();
        usuario = new Usuario();
        lblmenuBarras = new JLabel();
        Asignar = new CrearCurso(null,true);
        menuba = new ImageIcon(getClass().getResource("menuBarrasfn.png"));
        lblmenuBarras.setIcon(menuba);
        lblmenuBarras.setBounds(5, 5, 25, 25);
        lblmenuBarras.setVisible(false);
        lblmenuBarras.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        panelMenu.setVisible(true);
        panelFondo.add(lblmenuBarras);
        configclick = true;

         lblmenuBarras.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                menuBarrasMouseClicked(e);
            }
        });
    }

    public void asignarUsuario(Usuario usuario){
        this.usuario = usuario;
        lblUsuario.setText(usuario.getUsuario());
    }
    
    public void asignarTutor(Tutor tutor, int id){
        this.tutor = tutor;
        try{
        this.tutor = tutores.obtenerTutorconID(id);}
        catch(SQLException e){}

          System.out.println("prueba 1: " + tutor.getNombre());
          System.out.println("prueba 2: " + tutor.getId());
         try{
         List<Curso> listaCursos = cursos.getCursosPorTutor(tutor.getId());
         if(listaCursos != null){
         for (Curso curso : listaCursos) {
                // Obtener materias por el ID de materia del curso actual
                List<Materia> materiasPorCurso = materias.obtenerMateriasPorId(curso.getIdMateria());
                listaMaterias.addAll(materiasPorCurso); // Agregar todas las materias a la lista

                // Obtener alumnos por el ID de materia del curso actual
                List<Alumno> alumnosPorCurso = alumnos.getAlumnosPorIdMateria(curso.getIdMateria());
                listaAlumnos.addAll(alumnosPorCurso); // Agregar todos los alumnos a la lista
            }

         
         for(Materia mat: listaMaterias){
             System.out.println(""+mat.getNombre());
             cboMaterias.addItem(mat.getNombre());
         }
         
        cboMaterias.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        String materiaSeleccionada = (String) cboMaterias.getSelectedItem();
        
        // Limpiar el comboBox de alumnos antes de llenar
        DefaultComboBoxModel<String> modeloAlumnos = (DefaultComboBoxModel<String>) cboAlumnos.getModel();
        modeloAlumnos.removeAllElements(); // Limpiar el comboBox de alumnos
        modeloAlumnos.addElement("Selecciona un Alumno");
        
                    lblNombre.setText(""); // Asumiendo que tienes un JLabel lblNombre
                    lblAPaterno.setText(""); // Asumiendo que tienes un JLabel lblAPaterno
                    lblAMaterno.setText(""); // Asumiendo que tienes un JLabel lblAMaterno
                    lblNumControl.setText(""); // Asumiendo que tienes un JLabel lblNumControl
        
        if (materiaSeleccionada != null) {
            try {
                // Obtener la materia por su nombre
                Materia materia = materias.obtenerMateriaPorNombre(materiaSeleccionada);
                if (materia != null) {
                    // Obtener los alumnos para la materia seleccionada
                    listaAlumnos = alumnos.getAlumnosPorIdMateria(materia.getId());
                    
                    if (!listaAlumnos.isEmpty()) {
                        // Llenar el JComboBox de alumnos
                        for (Alumno alum : listaAlumnos) {
                            modeloAlumnos.addElement(alum.getNombre());
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "Aún no hay alumnos inscritos");
                    }
                }
            } catch (SQLException ex) {
                ex.printStackTrace(); // Manejo de excepción
            }
        }
        // Actualizar el modelo del JComboBox
        cboAlumnos.setModel(modeloAlumnos); // Asegúrate de que este sea tu JComboBox para alumnos
    }
});


        
        cboAlumnos.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        String alumnoSeleccionado = (String) cboAlumnos.getSelectedItem();
        if (alumnoSeleccionado != null) {
            try {
                // Obtener el alumno por su nombre
                Alumno alumno = alumnos.obtenerAlumnoPorNombre(alumnoSeleccionado); // Debes tener este método
                if (alumno != null) {
                    // Actualizar los JLabels con los datos del alumno
                    lblNombre.setText(alumno.getNombre()); // Asumiendo que tienes un JLabel lblNombre
                    lblAPaterno.setText(alumno.getAPaterno()); // Asumiendo que tienes un JLabel lblAPaterno
                    lblAMaterno.setText(alumno.getAMaterno()); // Asumiendo que tienes un JLabel lblAMaterno
                    lblNumControl.setText(String.valueOf(alumno.getNumControl())); // Asumiendo que tienes un JLabel lblNumControl
                }
            } catch (SQLException ex) {
                ex.printStackTrace(); // Manejo de excepción
            }
        }
    }
});

         
         }else{
             
         }
         }
         catch(SQLException e){}
                
    }
    
     public Tutor obtenerTutor() throws SQLException {
        //if (usuario != null) {
            String correoTutor = usuario.getCorreo();
            System.out.println("Correo del tutor en obtenerTutor: " + correoTutor);
            tutor = tutores.getTutorconCorreo(correoTutor);
            System.out.println("nombre del tutor obtenerTutor() "+tutor.getNombre());
            return tutor;
       // } else {
         //  throw new IllegalStateException("Usuario no asignado");
       // }
    }
     
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        menuOpciones = new javax.swing.JPopupMenu();
        separador1 = new javax.swing.JPopupMenu.Separator();
        menuoptCerrar = new javax.swing.JMenuItem();
        panelFondo = new javax.swing.JPanel();
        panelMenu = new javax.swing.JPanel();
        lblHogar = new javax.swing.JLabel();
        lblTutores = new javax.swing.JLabel();
        lblAlumnos = new javax.swing.JLabel();
        lblRetroceder = new javax.swing.JLabel();
        lblConfig = new javax.swing.JLabel();
        paneltitulo = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        lblImagenAdorno = new javax.swing.JLabel();
        lblUsuario = new javax.swing.JLabel();
        panelMaterias = new javax.swing.JPanel();
        panelBotones = new javax.swing.JPanel();
        jPanel10 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        cboMaterias = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        lblNombre = new javax.swing.JLabel();
        lblAPaterno = new javax.swing.JLabel();
        jSeparator2 = new javax.swing.JSeparator();
        lblAMaterno = new javax.swing.JLabel();
        jSeparator3 = new javax.swing.JSeparator();
        lblNumControl = new javax.swing.JLabel();
        jSeparator4 = new javax.swing.JSeparator();
        jLabel12 = new javax.swing.JLabel();
        cboAlumnos = new javax.swing.JComboBox<>();

        menuOpciones.add(separador1);

        menuoptCerrar.setText("Cerrar Sesión");
        menuoptCerrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuoptCerrarActionPerformed(evt);
            }
        });
        menuOpciones.add(menuoptCerrar);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Menu Principal");
        setResizable(false);

        panelFondo.setBackground(new java.awt.Color(255, 255, 255));

        panelMenu.setBackground(new java.awt.Color(0, 0, 204));

        lblHogar.setForeground(new java.awt.Color(255, 255, 255));
        lblHogar.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblHogar.setText("Hogar");
        lblHogar.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        lblHogar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblHogarMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblHogarMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblHogarMouseExited(evt);
            }
        });

        lblTutores.setForeground(new java.awt.Color(255, 255, 255));
        lblTutores.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTutores.setText("Mis clases");
        lblTutores.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        lblTutores.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblTutoresMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblTutoresMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblTutoresMouseExited(evt);
            }
        });

        lblAlumnos.setForeground(new java.awt.Color(255, 255, 255));
        lblAlumnos.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblAlumnos.setText("Recursos");
        lblAlumnos.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        lblAlumnos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblAlumnosMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblAlumnosMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblAlumnosMouseExited(evt);
            }
        });

        lblRetroceder.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/flecha.png"))); // NOI18N
        lblRetroceder.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblRetroceder.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblRetrocederMouseClicked(evt);
            }
        });

        lblConfig.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/configuracionb.png"))); // NOI18N
        lblConfig.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblConfig.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblConfigMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout panelMenuLayout = new javax.swing.GroupLayout(panelMenu);
        panelMenu.setLayout(panelMenuLayout);
        panelMenuLayout.setHorizontalGroup(
            panelMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelMenuLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblHogar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 88, Short.MAX_VALUE)
                    .addComponent(lblTutores, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblAlumnos, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelMenuLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(lblRetroceder, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelMenuLayout.createSequentialGroup()
                        .addComponent(lblConfig, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        panelMenuLayout.setVerticalGroup(
            panelMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelMenuLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblRetroceder, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(39, 39, 39)
                .addComponent(lblHogar, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblTutores, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblAlumnos, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 429, Short.MAX_VALUE)
                .addComponent(lblConfig, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        paneltitulo.setBackground(new java.awt.Color(204, 204, 204));

        jLabel1.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 24)); // NOI18N
        jLabel1.setText("Mis Alumnos");
        paneltitulo.add(jLabel1);

        lblImagenAdorno.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/userfn.png"))); // NOI18N

        lblUsuario.setFont(new java.awt.Font("Segoe UI Semibold", 1, 12)); // NOI18N
        lblUsuario.setText("Usuario");

        panelMaterias.setBackground(new java.awt.Color(255, 255, 255));

        panelBotones.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout panelBotonesLayout = new javax.swing.GroupLayout(panelBotones);
        panelBotones.setLayout(panelBotonesLayout);
        panelBotonesLayout.setHorizontalGroup(
            panelBotonesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 492, Short.MAX_VALUE)
        );
        panelBotonesLayout.setVerticalGroup(
            panelBotonesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 60, Short.MAX_VALUE)
        );

        jPanel10.setBackground(new java.awt.Color(255, 255, 255));

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel9.setText("Materia:");

        cboMaterias.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Selecciona una materia" }));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel2.setText("Nombre del Alumno:");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel3.setText("Apellido Paterno:");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel4.setText("Apellido Materno:");

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel5.setText("Num. Control:");

        lblNombre.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblNombre.setText("Nombre");

        lblAPaterno.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblAPaterno.setText("-");

        lblAMaterno.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblAMaterno.setText("-");

        lblNumControl.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblNumControl.setText("-");

        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel12.setText("Alumnos:");

        cboAlumnos.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Selecciona un alumno" }));
        cboAlumnos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboAlumnosActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel10Layout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addGap(57, 57, 57)
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(lblNumControl, javax.swing.GroupLayout.DEFAULT_SIZE, 263, Short.MAX_VALUE)
                            .addComponent(jSeparator4)))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel10Layout.createSequentialGroup()
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addComponent(jLabel4)
                            .addGroup(jPanel10Layout.createSequentialGroup()
                                .addGap(24, 24, 24)
                                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel12)
                                    .addComponent(jLabel9))))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(cboMaterias, javax.swing.GroupLayout.PREFERRED_SIZE, 235, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jSeparator3)
                                .addComponent(jSeparator1)
                                .addComponent(lblNombre, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jSeparator2)
                                .addComponent(lblAPaterno, javax.swing.GroupLayout.DEFAULT_SIZE, 263, Short.MAX_VALUE)
                                .addComponent(lblAMaterno, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addComponent(cboAlumnos, javax.swing.GroupLayout.PREFERRED_SIZE, 235, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(31, 78, Short.MAX_VALUE))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cboMaterias, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9))
                .addGap(18, 18, 18)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12)
                    .addComponent(cboAlumnos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(41, 41, 41)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblNombre)
                    .addComponent(jLabel2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblAPaterno)
                    .addComponent(jLabel3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addComponent(jLabel4))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblAMaterno)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(lblNumControl, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(5, 5, 5)
                .addComponent(jSeparator4, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout panelMateriasLayout = new javax.swing.GroupLayout(panelMaterias);
        panelMaterias.setLayout(panelMateriasLayout);
        panelMateriasLayout.setHorizontalGroup(
            panelMateriasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelMateriasLayout.createSequentialGroup()
                .addGroup(panelMateriasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelMateriasLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(panelBotones, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        panelMateriasLayout.setVerticalGroup(
            panelMateriasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelMateriasLayout.createSequentialGroup()
                .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(panelBotones, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout panelFondoLayout = new javax.swing.GroupLayout(panelFondo);
        panelFondo.setLayout(panelFondoLayout);
        panelFondoLayout.setHorizontalGroup(
            panelFondoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelFondoLayout.createSequentialGroup()
                .addComponent(panelMenu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(panelFondoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(paneltitulo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelFondoLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblImagenAdorno, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblUsuario)
                        .addGap(25, 25, 25))
                    .addGroup(panelFondoLayout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(panelMaterias, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        panelFondoLayout.setVerticalGroup(
            panelFondoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelMenu, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(panelFondoLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelFondoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblImagenAdorno, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblUsuario, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(paneltitulo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(panelMaterias, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelFondo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelFondo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void lblRetrocederMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblRetrocederMouseClicked
        panelMenu.setVisible(false);
        lblmenuBarras.setVisible(true);
    }//GEN-LAST:event_lblRetrocederMouseClicked

    private void lblConfigMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblConfigMouseClicked
        if(configclick == true){
        menuOpciones.show(this, lblConfig.getX(), lblConfig.getY()-25);
        configclick=false;
        }else if(configclick == false){
            menuOpciones.setVisible(false);
            configclick = true;
        }
    }//GEN-LAST:event_lblConfigMouseClicked

    private void menuoptCerrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuoptCerrarActionPerformed
        Loggin lg = new Loggin();
        lg.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_menuoptCerrarActionPerformed

    private void lblHogarMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblHogarMouseEntered
       lblHogar.setFont(lblHogar.getFont().deriveFont(Font.BOLD));
    }//GEN-LAST:event_lblHogarMouseEntered

    private void lblHogarMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblHogarMouseExited
        lblHogar.setFont(lblHogar.getFont().deriveFont(Font.PLAIN));
    }//GEN-LAST:event_lblHogarMouseExited

    private void lblTutoresMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblTutoresMouseEntered
        lblTutores.setFont(lblTutores.getFont().deriveFont(Font.BOLD));
    }//GEN-LAST:event_lblTutoresMouseEntered

    private void lblTutoresMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblTutoresMouseExited
        lblTutores.setFont(lblTutores.getFont().deriveFont(Font.PLAIN));
    }//GEN-LAST:event_lblTutoresMouseExited

    private void lblAlumnosMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblAlumnosMouseEntered
        lblAlumnos.setFont(lblAlumnos.getFont().deriveFont(Font.BOLD));
    }//GEN-LAST:event_lblAlumnosMouseEntered

    private void lblAlumnosMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblAlumnosMouseExited
        lblAlumnos.setFont(lblAlumnos.getFont().deriveFont(Font.PLAIN));
    }//GEN-LAST:event_lblAlumnosMouseExited

    private void lblHogarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblHogarMouseClicked
         this.dispose();
        MenuPrincipalTutor mp = new MenuPrincipalTutor();
        mp.asignarUsuario(usuario);
        mp.setVisible(true);
       
    }//GEN-LAST:event_lblHogarMouseClicked

    private void lblTutoresMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblTutoresMouseClicked
         try{       
    this.dispose();
        VentanaMisClasesTutores va = new VentanaMisClasesTutores();
       // System.out.println("prueba si se obtien el hola " + hola);
        va.asignarTutor(obtenerTutor(), obtenerTutor().getId());
        va.asignarUsuario(usuario);
       va.setVisible(true);}
        catch(SQLException e){}
       
    }//GEN-LAST:event_lblTutoresMouseClicked

    private void lblAlumnosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblAlumnosMouseClicked
        this.dispose();
        VentanaRecursos va = new VentanaRecursos();
        va.asignarUsuario(usuario);
       va.setVisible(true);
    }//GEN-LAST:event_lblAlumnosMouseClicked

    private void cboAlumnosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboAlumnosActionPerformed
        
    }//GEN-LAST:event_cboAlumnosActionPerformed

    private void menuBarrasMouseClicked(MouseEvent e) {
        lblmenuBarras.setVisible(false);
        panelMenu.setVisible(true);
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VentanaAlumnosTutor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VentanaAlumnosTutor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VentanaAlumnosTutor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VentanaAlumnosTutor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VentanaAlumnosTutor().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> cboAlumnos;
    private javax.swing.JComboBox<String> cboMaterias;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JLabel lblAMaterno;
    private javax.swing.JLabel lblAPaterno;
    private javax.swing.JLabel lblAlumnos;
    private javax.swing.JLabel lblConfig;
    private javax.swing.JLabel lblHogar;
    private javax.swing.JLabel lblImagenAdorno;
    private javax.swing.JLabel lblNombre;
    private javax.swing.JLabel lblNumControl;
    private javax.swing.JLabel lblRetroceder;
    private javax.swing.JLabel lblTutores;
    private javax.swing.JLabel lblUsuario;
    private javax.swing.JPopupMenu menuOpciones;
    private javax.swing.JMenuItem menuoptCerrar;
    private javax.swing.JPanel panelBotones;
    private javax.swing.JPanel panelFondo;
    private javax.swing.JPanel panelMaterias;
    private javax.swing.JPanel panelMenu;
    private javax.swing.JPanel paneltitulo;
    private javax.swing.JPopupMenu.Separator separador1;
    // End of variables declaration//GEN-END:variables
}
